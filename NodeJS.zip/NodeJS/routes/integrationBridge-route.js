const router = require("express").Router();
const {loggedIn, adminOnly, validateSession, validatePaswordResetSession} = require("../helpers/auth.middleware");
const intBridgeController = require("../controllers/integrationBridge.controller");

router.post("/getAllIntBridge", loggedIn, intBridgeController.getAllIntBridge);
router.post("/createIntBridge", loggedIn, intBridgeController.createIntBridge);
router.post("/editIntBridge", loggedIn, intBridgeController.editIntBridge);
router.put("/updateIntBridge", loggedIn, intBridgeController.updateIntBridge);
router.delete("/deleteIntBridge/:id", loggedIn, intBridgeController.deleteIntBridge);

router.post("/refreshService", loggedIn, intBridgeController.refreshService);

router.get("/getInstance", loggedIn, intBridgeController.getInstance);
router.post("/editInstance", loggedIn, intBridgeController.editInstance);
router.put("/updateInstance", loggedIn, intBridgeController.updateInstance);
router.post("/getPostmanData", loggedIn, intBridgeController.getPostmanData);

router.post("/startService", loggedIn, intBridgeController.startService);
router.post("/stopService", loggedIn, intBridgeController.stopService);

router.post("/getServiceStatus", loggedIn, intBridgeController.getServiceStatus);

module.exports = router;
const router = require('express').Router();
const { loggedIn } = require("../helpers/auth.middleware");
const sourceController = require('../controllers/source.controller');

// source
router.post('/saveSource', loggedIn, sourceController.saveSource);
router.get('/getSourceList', loggedIn, sourceController.getSourceList);
router.get('/getSource', loggedIn, sourceController.getSource);
router.post('/testSource', loggedIn, sourceController.testSource);

module.exports = router;
const router = require('express').Router();
const { loggedIn } = require("../helpers/auth.middleware");
const apiCatalogueController = require('../controllers/api-catalogue.controller');

router.get("/getCategory", loggedIn, apiCatalogueController.getCategory);
router.post("/getBrand", loggedIn, apiCatalogueController.getBrand);
router.get("/getPrice", loggedIn, apiCatalogueController.getPrice);
router.get("/getType", loggedIn, apiCatalogueController.getType);
router.get("/getMethod", loggedIn, apiCatalogueController.getApiMethod);
router.get("/getAuth", loggedIn, apiCatalogueController.getApiAuthType);
router.post("/createApiCatalogue", loggedIn, apiCatalogueController.createApiCatalogue);
router.post("/getApiCatalogue", loggedIn, apiCatalogueController.getApiCatalogue);
router.post("/getApiCatalogueSource", loggedIn, apiCatalogueController.getApiCatalogueSource);

router.post("/getAllCategories", loggedIn, apiCatalogueController.getAllCategories);
router.post("/createCategory", loggedIn, apiCatalogueController.createCategory);
router.post("/editCategory", loggedIn, apiCatalogueController.editCategory);
router.put("/updateCategory", loggedIn, apiCatalogueController.updateCategory);
router.delete("/deleteCategory/:ID", loggedIn, apiCatalogueController.deleteCategory);

/*  Purpose: The following routes defined for the api_catalogue_source data 
*   Author: Mallikarjuna Nayak
*	Date: 22-02-2022
*/
router.put("/updateApiCatalogueSource", loggedIn, apiCatalogueController.updateApiCatalogueSource);
router.delete("/deleteApiCatalogueSource/:ID", loggedIn, apiCatalogueController.deleteApiCatalogueSource);

/*  Purpose: The following routes defined for the Brand data 
*   Author: Mallikarjuna Nayak
*	Date: 24-02-2022
*/
router.post("/getAllBrands", loggedIn, apiCatalogueController.getAllBrands);
router.post("/createNewBrand", loggedIn, apiCatalogueController.createNewBrand);
router.post("/editBrand", loggedIn, apiCatalogueController.editBrand);
router.put("/updateBrand", loggedIn, apiCatalogueController.updateBrand);
router.delete("/deleteBrand/:ID", loggedIn, apiCatalogueController.deleteBrand);
router.post("/getBrandsByCatId", loggedIn, apiCatalogueController.getBrandsByCatId);

router.post("/apiCatalogCall", loggedIn, apiCatalogueController.apiCatalogCall);
/*  Purpose: The following route is defined for the shell script commands
*   Author: Mallikarjuna Nayak
*	Date: 28-03-2022
*/
router.post("/apiAnsibleCmd", loggedIn, apiCatalogueController.apiAnsibleCmd);
/*  Purpose: The following route is defined for to get Catalogue Source and Target
*   Author: Mallikarjuna Nayak
*	Date: 06-04-2022
*/
router.post("/getCatalogueSourceTarget", loggedIn, apiCatalogueController.getCatalogueSourceTarget);

router.post("/getBusinessObject", loggedIn, apiCatalogueController.getBusinessObject);

module.exports = router;
const router = require('express').Router();
const {loggedIn, adminOnly, validateSession, validatePaswordResetSession} = require("../helpers/auth.middleware");
const apiOrganizationController = require('../controllers/organization.controller');
const multer = require("multer");
const upload = multer({ dest: "uploads/" });

router.post("/getApiOrganization", loggedIn, apiOrganizationController.getApiOrganization);
router.post("/editApiOrganization", loggedIn, apiOrganizationController.editApiOrganization);
router.put("/updateApiOrganization", loggedIn, apiOrganizationController.updateApiOrganization);
router.delete("/delApiOrganization/:ID", loggedIn, apiOrganizationController.delApiOrganization);

router.post("/saveCompanyLogo", loggedIn, upload.single("logo"), apiOrganizationController.saveCompanyLogo);
router.put("/updateCompanyLogo", loggedIn, upload.single("logo"), apiOrganizationController.updateCompanyLogo);
router.post("/getLogoImage", loggedIn, apiOrganizationController.getLogoImage);
router.delete("/deleteLogoImage/:orgId/:collectionId", loggedIn, apiOrganizationController.deleteLogoImage);

router.post("/getProfileInfo", loggedIn, apiOrganizationController.getProfileInfo);
router.put("/updateProfileInfo", loggedIn, apiOrganizationController.updateProfileInfo);

module.exports = router;
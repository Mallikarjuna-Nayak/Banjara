const router = require("express").Router();
const {loggedIn, adminOnly, validateSession, validatePaswordResetSession} = require("../helpers/auth.middleware");
const getCountriesController = require("../controllers/countries.controller");

router.get("/getAllCountries",  getCountriesController.getAllCountries);

module.exports = router;
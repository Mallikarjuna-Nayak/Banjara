const router = require("express").Router();
const {loggedIn, adminOnly, validateSession, validatePaswordResetSession} = require("../helpers/auth.middleware");
const userRoleController = require("../controllers/userRole.controller");

/*  Purpose: The following routes defining for the user roles data 
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
router.post("/userRoles", loggedIn, userRoleController.userRoles);
router.post("/createUserRole", loggedIn, userRoleController.createUserRole);
router.post("/editUserRole", loggedIn, userRoleController.editUserRole);
router.put("/updateUserRole", loggedIn, userRoleController.updateUserRole);
router.delete("/deleteUserRole/:id", loggedIn, userRoleController.deleteUserRole);

/*  Purpose: The following routes defining for the user Permissions data 
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
router.post("/allPermissions", loggedIn, userRoleController.allPermissions);
router.post("/createPermission", loggedIn, userRoleController.createPermission);
router.post("/editPermission", loggedIn, userRoleController.editPermission);
router.put("/updatePermission", loggedIn, userRoleController.updatePermission);
router.delete("/deletePermission/:id", loggedIn, userRoleController.deletePermission);

/*  Purpose: The following routes defining for the user role based Permissions data 
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
//router.post("/allRolePermissions", loggedIn, userRoleController.allRolePermissions);
//router.post("/createRolePermission", loggedIn, userRoleController.createRolePermission);
//router.post("/editRolePermission", loggedIn, userRoleController.editRolePermission);
//router.put("/updateRolePermission", loggedIn, userRoleController.updateRolePermission);
//router.delete("/deleteRolePermission/:id", loggedIn, userRoleController.deleteRolePermission);

module.exports = router;
const router = require('express').Router();
const { loggedIn } = require("../helpers/auth.middleware");
const targetController = require('../controllers/target.controller');

// target
router.post('/saveTarget', loggedIn, targetController.saveTarget);
router.get('/getTargetList', loggedIn, targetController.getTargetList);
router.get('/getTarget', loggedIn, targetController.getTarget);

module.exports = router;
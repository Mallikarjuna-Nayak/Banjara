const router = require("express").Router();
const {loggedIn, adminOnly, validateSession, validatePaswordResetSession} = require("../helpers/auth.middleware");
const userController = require("../controllers/user.controller");
const multer = require("multer");
const upload = multer({ dest: "uploads/" });

// Register a new User
router.post("/register", userController.register);

// Account verification
router.post("/getCode", userController.getVerificationCode);
router.post("/sendCode", userController.sendVerificationCode);

// Set new User password
router.post("/setPassword", userController.setNewPassword);
router.get("/securityQuestions", userController.getSecurityQuestions);

router.get("/subscribe", loggedIn, userController.subscribe);

// Login
router.post("/login", userController.login);

// session validation
router.get("/authuseronly", loggedIn, userController.authuseronly);

// Auth user only
router.get("/validateLoggedInSession", validateSession, userController.validateLoggedInSession);
router.get("/refreshToken", loggedIn, userController.refreshToken);

router.post("/forgotPassword", userController.forgotPassword);
router.post("/changePassword", validatePaswordResetSession, userController.changePassword);
router.post("/resetPassword", userController.resetPassword);
router.post("/changeExistingPassword", loggedIn, userController.changeExistingPassword);

// Admin user only
router.get("/adminonly", loggedIn, adminOnly, userController.adminonly);

router.post("/saveProfileImage", loggedIn, upload.single("profileImage"), userController.saveProfileImage);
router.put("/updateProfileImage", loggedIn, upload.single("profileImage"), userController.updateProfileImage);
router.post("/getUserProfileImage", loggedIn, userController.getUserProfileImage);
router.delete("/deleteUserProfileImage/:userId/:collectionId", loggedIn, userController.deleteUserProfileImage);

router.delete("/deleteUser/:id", loggedIn, userController.deleteUser);
router.post("/getAllUsers", loggedIn, userController.getAllUsers);
/*  Purpose: The following routes defining for the user data
*   Author: Mallikarjuna Nayak
*	Date: 11-02-2022
*/
router.post("/getApiUser", loggedIn, userController.userApiEdit);
router.put("/updateApiUser", loggedIn, userController.updateApiUser);
router.post("/createNewUserApi", loggedIn, userController.createNewUserApi);

/*  Purpose: The following routes defining for the user_group data 
*   Author: Mallikarjuna Nayak
*	Date: 14-02-2022
*/
router.post("/getAllUserGroups", loggedIn, userController.getAllUserGroups);
router.post("/addUserGroups", loggedIn, userController.addUserGroups);
router.post("/editUserGroups", loggedIn, userController.editUserGroups);
router.put("/updateUserGroups", loggedIn, userController.updateUserGroups);
router.delete("/deleteUserGroups/:ID", loggedIn, userController.deleteUserGroups);

router.post("/setLogoImage", userController.setLogoImage);

router.post("/changeUserPassword", loggedIn, userController.changeUserPassword);

module.exports = router;
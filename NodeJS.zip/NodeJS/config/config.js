module.exports = {
  DB_HOST: "localhost",
  DB_USER: "root",
  DB_PASSWORD: "",
  DB_NAME: "guidednav",
  TOKEN_SECRET: "sE6ret0gfknf",
  PASSWORD_RESET_TOKEN_SECRET: "ssertdsfsdthret0gnf",
  COMPANY_EMAIL: "team@bizdata360.com",
  EMAIL_HOST: "mail.bizdata360.com",
  COMPANY_PASSWORRD: "pr2rq@RWecwj@lT5qw1@Aic",
  EMAIL_PORT: 465,
  DEFAULT_GROUP: { id: 2, title: "Admin" },
};

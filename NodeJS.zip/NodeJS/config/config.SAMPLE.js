module.exports = {
    DB_HOST: "DB_HOST",
    DB_USER: "DB_USER",
    DB_PASSWORD: "DB_PASSWORD",
    DB_NAME: "DB_NAME",
    TOKEN_SECRET: 'RANDOM_STRING'
};
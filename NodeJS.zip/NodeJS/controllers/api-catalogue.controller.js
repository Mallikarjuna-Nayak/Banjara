const catalogue_model = require("../models/api-catalogue.model");
const catalogue_hash = require("../helpers/catalogue");
const axios = require('axios');
const { head } = require("../routes/api-catalogue-route");
const ansible = require('node-ansible');

/**
 * Get Category -> create api catalogue
 * Author: Piklu Chakraborty
 */
exports.getCategory = async (req, res) => {
    try {
        const rows = await catalogue_model.getCategory();
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.getAllCategories = async (req, res) => {
    try {
        let sort = req.body.sort? req.body.sort: "";
        let order = req.body.order? req.body.order: "";
        let search = req.body.q? req.body.q: "";
        let cnt = await catalogue_model.getAllCategoryCount();
        const rows = await catalogue_model.getAllCategories(req.body.min, req.body.max, cnt, sort, order, search);
        res.send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.createCategory = async (req, res) => {
    try {
        const rows = await catalogue_model.createCategory(req.body);
        if(rows) {
            let data = {msg:"New Category is created"};
            res.send(data);
        }
        res.send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.editCategory = async (req, res) => {
    try {
        const rows = await catalogue_model.editCategory(req.body.ID);
        res.send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.updateCategory = async (req, res) => {
    try {
        const rows = await catalogue_model.updateCategory(req.body);
        if(rows)
		{
			let data = {msg:"Record has been updated"};
            res.send(data);
		}
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.deleteCategory = async (req, res) => {
    try {
        const rows = await catalogue_model.deleteCategory(req.params.ID);
        if(rows)
        {
            let data = {msg:"Record has been deleted"};
            res.send(data);
        }
      } catch (error) {
          res.status(400).send(error);
      }
  }

/**
 * Get Brand based on Category selection -> create api catalogue
 * Author: Piklu Chakraborty
 */
exports.getBrand = async(req, res) => {
    try {
        const brandsArr = req.body.brands;
        const rows = await catalogue_model.getBrand(brandsArr);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Get Price -> create api catalogue
 * Author: Piklu Chakraborty
 */
exports.getPrice = async(req, res) => {
    try {
        const rows = await catalogue_model.getPrice();
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Get Type -> create api catalogue
 * Author: Piklu Chakraborty
 */
exports.getType = async(req, res) => {
    try {
        const rows = await catalogue_model.getType();
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Get Api Method -> create api catalogue
 * Author: Piklu Chakraborty
 */
exports.getApiMethod = async(req, res) => {
    try {
        const rows = await catalogue_model.getApiMethod();
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Get Authorization Type -> create api catalogue
 * Author: Piklu Chakraborty
 */
exports.getApiAuthType = async(req, res) => {
    try {
        const rows = await catalogue_model.getApiAuthType();
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Insert Catalogue -> create api catalogue
 * Author: Piklu Chakraborty
 */
exports.createApiCatalogue = async(req, res) => {
    try {
        const api_category = req.body.api_category;
        const api_brand  = req.body.api_brand;
        const api_price = req.body.api_price;
        const api_type = req.body.api_type;
        const api_commerce = req.body.api_commerce;
        const api_version = req.body.api_version;
        const api_product_name = req.body.api_product_name;
        const api_business_object = req.body.api_business_object;
        const api_created_by = req.body.created_by;
        const create_ip_address = req.body.create_ip_address;
        const api_source_name = req.body.api_source_name;
        const api_object_keyword = req.body.api_object_keyword;
        const api_description = req.body.api_description;
        const filter_type = req.body.filter_type;
        const parameter1 = req.body.parameter1;
        const parameter2 = req.body.parameter2;
        const parameter3 = req.body.parameter3;
        const parameter4 = req.body.parameter4;
        
        let data = await catalogue_hash.catalogue(req.body.api_input_structure);
        let store_object = {
            api_category,
            api_brand,
            api_price,
            api_type,
            api_commerce,
            api_version,
            api_product_name,
            api_business_object,
            api_created_by,
            create_ip_address,
            api_source_name,
            api_object_keyword,
            api_description,
            filter_type,
            parameter1,
            parameter2,
            parameter3,
            parameter4,
            input_structure_hash: data.input_structure_hash,
            input_structure_json: JSON.stringify(data.input_structure_json)
        }

        let result = await catalogue_model.insertApiCatalogue(store_object);
        if(result == true){
            let data = {
                msg: "Api Catalogue created successfully",
            };
            res.status(200).json(data);
        }
        
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Get All Catalogue -> create api catalogue
 * Author: Piklu Chakraborty
 */
exports.getApiCatalogue = async(req, res) => {
    try {
        let sort = req.body.sort? req.body.sort: "";
        let order = req.body.order? req.body.order: "";
        let search = req.body.q? req.body.q: "";
        const cnt = await catalogue_model.getTotalCatalogCount();
        const rows = await catalogue_model.getApiCatalogue(req.body.min, req.body.max, cnt, sort, order, search);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Get All Catalogue -> Get all api catalogue sources
 * Author: Mallikarjuna Nayak
	Date: 09-02-2022
 */
exports.getApiCatalogueSource = async(req, res) => {
    try {
        const rows = await catalogue_model.getApiCatalogueSource(req.body.ID);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Purpose: Update api_catalogue_source details with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 22-02-2022
 */
exports.updateApiCatalogueSource = async (req, res) => {
    try {
		const api_category = req.body.api_category;
        const api_brand  = req.body.api_brand;
        const api_price = req.body.api_price;
        const api_type = req.body.api_type;
        const api_commerce = req.body.api_commerce;
        const api_version = req.body.api_version;
        const api_product_name = req.body.api_product_name;
        const api_business_object = req.body.api_business_object;
        const api_updated_by = req.body.updated_by;
        const update_ip_address = req.body.update_ip_address;
        const api_source_name = req.body.api_source_name;
        const api_object_keyword = req.body.api_object_keyword;
        const api_description = req.body.api_description;
        const filter_type = req.body.filter_type;
        const parameter1 = req.body.parameter1;
        const parameter2 = req.body.parameter2;
        const parameter3 = req.body.parameter3;
        const parameter4 = req.body.parameter4;
        
        let data = await catalogue_hash.catalogue(req.body.api_input_structure);
        let store_object = {
            api_category,
            api_brand,
            api_price,
            api_type,
            api_commerce,
            api_version,
            api_product_name,
            api_business_object,
            api_updated_by,
            update_ip_address,
            api_source_name,
            api_object_keyword,
            api_description,
            filter_type,
            parameter1,
            parameter2,
            parameter3,
            parameter4,
            input_structure_hash: data.input_structure_hash,
            input_structure_json: JSON.stringify(data.input_structure_json),
            id: req.body.ID
        }

        let status = {};
        let result = await catalogue_model.updateApiCatalogueSource(store_object);
        if(result == true){
            status = {
                msg: "Catalogue data has been updated",
            };
        } else {
            status = {
                msg: "Error: Unable to update Catalogue data",
            };
        }
        res.status(200).send(status);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Delete api_catalogue_source data with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 22-02-2022
 */
exports.deleteApiCatalogueSource = async (req, res) => {
  try {
	  const rows = await catalogue_model.deleteApiCatalogueSource(req.params.ID);
      if(rows)
	  {
		  let data = {msg:"Record has been deleted"};
		  res.send(data);
	  }
    } catch (error) {
        res.status(400).send(error);
    }
  
}
/**
 * Purpose: Get all brands data in the request
 * Author: Mallikarjuna Nayak
 * Date: 24-02-2022
 */
exports.getAllBrands = async (req, res) => {
  try {
	  const cnt = await catalogue_model.getTotalBrands();
      const rows = await catalogue_model.getAllBrands(req.body.min, req.body.max, cnt, req.body.sort, req.body.order, req.body.q);
      res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Create New Brand data in the request
 * Author: Mallikarjuna Nayak
 * Date: 24-02-2022
 */
exports.createNewBrand = async (req, res) => {
	try {
		const rows = await catalogue_model.CreateNewBrand(req.body);
		if(rows) {
			let data = {msg:"New Brand is created"};
			res.send(data);
		}
		res.status(200).send(rows);
	} catch (error) {
		res.status(400).send(error);
	}
}
/**
 * Purpose: Get brand and brand_category_map data to edit by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 24-02-2022
 */
exports.editBrand = async (req, res) => {
    try {
		let brand_cat = await catalogue_model.getbrandCatMap(req.body.ID);
        const rows = await catalogue_model.editBrand(req.body.ID, brand_cat);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Update brand and brand_category_map data by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 24-02-2022
 */
exports.updateBrand = async (req, res) => {
    try {
        const rows = await catalogue_model.updateBrand(req.body);
        if(rows)
		{
			let data = {msg:"Record has been updated"};
				res.send(data);
		}
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Delete brand with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 24-02-2022
 */
exports.deleteBrand = async (req, res) => {
  try {
	  const rows = await catalogue_model.deleteBrand(req.params.ID);
      if(rows)
	  {
		  let data = {msg:"Record has been deleted"};
		  res.send(data);
	  }
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get brands data by specified category_id in the request
 * Author: Mallikarjuna Nayak
 * Date: 24-02-2022
 */
exports.getBrandsByCatId = async (req, res) => {
    try {
		const rows = await catalogue_model.getBrandsByCatId(req.body.ID);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.apiCatalogCall = async (req, res) => {
    let method = req.body.method;
    let url = req.body.endpointUrl;
    let authType = req.body.authType;
    let payload = req.body.payload;
    let customHeaders = req.body.customHeaders;
    let params = req.body.params;
    var headerObj = {};
    var customHdr = {};

// ******** IF PARAMS PROVIDED **********************************  
    if(params) {
        let queryString;
        url += '?';
        let arrStr = [];
        let tempArr = [];
        params.forEach((e, index) => {
            tempArr = Object.keys(e).map(key => key + '=' + e[key]);
            arrStr.push(...tempArr);
            queryString = arrStr.join('&');
          });
        url += queryString;
    }

// ******** *************************** ********************************

// ******** IF AUTHORIZATION PROVIDED **********************************
    if(authType) {
        if(authType.id == 3 || authType.id == 4) {
            //Bearer Token / Basic Auth
            headerObj = {
                headers: {
                            Authorization: req.body.auth
                        }
            };
        }

        if(authType.id == 6) {
			
            //OAuth 2.0
			
        }
    }
// ******** *************************** ********************************

// ******** IF HEADERS PROVIDED **********************************
    if(customHeaders) {
        customHdr = {
            headers: customHeaders
        };
    }
// ******** *************************** ********************************

headerObj = Object.assign(customHdr, headerObj);
// console.log(headerObj);

    //GET method
    if(method.id == 1){
        axios.get(url, headerObj)
        .then(function (response) {
            let data =  {
                "status": response.status,
                "statusText": response.statusText,
                "data": response.data
            }
            res.send(data);
        })
        .catch(function (error) {
            let data;
            if(error.response){
                data =  {
                    "error": "1",
                    "status": error.response.status,
                    "statusText": error.response.statusText,
                    "data": error.response.data
                }
                res.send(data);
            }else{
                data = {
                    "error": "2",
                    "message": error.message,
                    "statusText": error.code
                }
                res.send(data);
            }
        });
    }

    //POST method
    if(method.id == 2){
        axios.post(url, payload, headerObj)
        .then(function (response) {
            //console.log(response);
            let data =  {
                "status": response.status,
                "statusText": response.statusText,
                "data": response.data
            }
            res.send(data);
        })
        .catch(function (error) {
            console.log(error);
            let data;
            if(error.response){
                data =  {
                    "error": "1",
                    "status": error.response.status,
                    "statusText": error.response.statusText,
                    "data": error.response.data
                }
                res.send(data);
            }else{
                data = {
                    "error": "2",
                    "message": error.message,
                    "statusText": error.code
                }
                res.send(data);
            }
            
        });
    }

    //PUT method
    if(method.id == 3){
        axios.put(url, payload, headerObj)
        .then(function (response) {
            let data =  {
                "status": response.status,
                "statusText": response.statusText,
                "data": response.data
            }
            res.send(data);
        })
        .catch(function (error) {
            let data;
            if(error.response){
                data =  {
                    "error": "1",
                    "status": error.response.status,
                    "statusText": error.response.statusText,
                    "data": error.response.data
                }
                res.send(data);
            }else{
                data = {
                    "error": "2",
                    "message": error.message,
                    "statusText": error.code
                }
                res.send(data);
            }
        });
    }

    //DELETE method
    if(method.id == 4) {
        axios.delete(url, headerObj)
        .then(function (response) {
            let data =  {
                "status": response.status,
                "statusText": response.statusText,
                "data": response.data
            }
            res.send(data);
        })
        .catch(function (error) {
            let data;
            if(error.response){
                data =  {
                    "error": "1",
                    "status": error.response.status,
                    "statusText": error.response.statusText,
                    "data": error.response.data
                }
                res.send(data);
            }else{
                data = {
                    "error": "2",
                    "message": error.message,
                    "statusText": error.code
                }
                res.send(data);
            }
        });
	}
}

/**
 * Purpose: Shell script command to execute the request
 * Author: Mallikarjuna Nayak
 * Date: 28-03-2022
 */
exports.apiAnsibleCmd = async (req, res) => {
	const { exec } = require("child_process");
	exec("ls -l", (error, stdout, stderr) => {
	//exec("'find . -type f'", (error, stdout, stderr) => {
		if (error) {
			console.log(`error: ${error.message}`);
			return;
		}
		if (stderr) {
			console.log(`stderr: ${stderr}`);
			return;
		}
		console.log(`stdout: ${stdout}`);
	});
}

/**
 * Purpose: The following function is defined for to get Catalogue Source and Target
 * Author: Mallikarjuna Nayak
 * Date: 06-04-2022
 */
 exports.getCatalogueSourceTarget = async (req, res) => {
	try {
		const rows = await catalogue_model.getCatalogueSourceTarget(req.body.q, req.body.type);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.getBusinessObject = async (req, res) => {
    try {
        const rows = await catalogue_model.getBussinessObject(req.body.type);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

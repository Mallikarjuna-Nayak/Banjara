const organization_model = require("../models/organization.model");
const multer  = require('multer');
const upload = multer({ dest: 'uploads/' });
const fs = require("fs");

/**
 * Get organization
 * Author: Jitendra Kelhe
 */
 exports.getApiOrganization = async (req, res) => {
    try {
        let cnt = await organization_model.getOrganizationCount();
        const rows = await organization_model.getOrganization(req.body.min, req.body.max, cnt, req.body.sort, req.body.order, req.body.q);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Purpose: Get a Organization details with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 10-02-2022
 */
exports.editApiOrganization = async (req, res) => {
    try {
        const rows = await organization_model.editApiOrganization(req.body.ID);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Purpose: Update a Organization details with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 10-02-2022
 */
exports.updateApiOrganization = async (req, res) => {
    try {
        const rows = await organization_model.updateApiOrganization(req.body);
        if(rows) {
            let data = {
                msg: "Successfully updated organization data",
            };
            res.send(data);
        }
    } catch (error) {
        res.status(400).send(error);
    }
}

/**
 * Purpose: Delete a Organization with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 10-02-2022
 */
exports.delApiOrganization = async (req, res) => {
  try {
	  const rows = await organization_model.removeApiOrganization(req.params.ID);
      if(rows){
        let data = {
            msg: "Record has been deleted",
          };
          res.send(data);
      }
    } catch (error) {
        res.status(400).send(error);
    }
  
}

exports.getLogoImage = async (req, res) => {
    try {
        const rows = await organization_model.getLogoImage(req.body.img_collection_id);
        res.status(200).send(rows);
    } catch (error) {
        res.status(404).send(error);
    }
}

exports.saveCompanyLogo = async (req, res) => {
    try {
        const buffer = fs.readFileSync("uploads/" + req.file.filename);
        var bufferBase64 = buffer.toString("base64");
        const rows = await organization_model.saveCompanyLogo(req.body.organization_id, bufferBase64);
        if(rows) {
            let data = { "logo_hash": bufferBase64 };
            res.send(data);
        }
    } catch (error) {
        res.status(404).send(error);
    }
}

exports.updateCompanyLogo = async (req, res) => {
    try {
        const buffer = fs.readFileSync("uploads/" + req.file.filename);
        var bufferBase64 = buffer.toString("base64");
        const rows = await organization_model.updateCompanyLogo(req.body.img_collection_id, bufferBase64);
        if(rows) {
            let data = { "logo_hash": bufferBase64 };
            res.send(data);
        }
    } catch (error) {
        res.status(404).send(error);
    }
}

exports.deleteLogoImage = async (req, res) => {
    try {
        const rows = await organization_model.deleteLogoImage(req.params.orgId, req.params.collectionId);
        if(rows){
          let data = {
              msg: "Logo has been deleted",
            };
            res.send(data);
        }
      } catch (error) {
          res.status(400).send(error);
      }
  }

/**
 * Get profile data
 * Author: Jitendra Kelhe
 */
 exports.getProfileInfo = async (req, res) => {
    try {
        const rows = await organization_model.getProfileInfo(req.body.ID);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}


/**
 * Purpose: Update profile
 * Author: Jitendra Kelhe
 */

 exports.updateProfileInfo = async (req, res) => {
    try {
        const rows = await organization_model.updateProfileInfo(req.body);
        if(rows) {
            let data = {
                msg: "Successfully updated profile",
            };
            res.send(data);
        }
    } catch (error) {
        res.status(400).send(error);
    }
}
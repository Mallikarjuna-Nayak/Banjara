const countries_model = require("../models/countries.model");

/**
 * Purpose: Get all Countries data in the request
 * Author: Mallikarjuna Nayak
 * Date: 14-02-2022
 */
exports.getAllCountries = async (req, res) => {
    try {
        const rows = await countries_model.getAllCountries();
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
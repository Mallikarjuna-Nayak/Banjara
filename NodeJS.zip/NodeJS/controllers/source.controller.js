const { NotFoundError } = require("../helpers/utility");
const Source = require("../models/source.model.js");
const SourceRepeat = require("../models/source-repeat.model");

exports.saveSource = async (req, res) => {
    try {
        const source = new Source(req.body, req.user.id);
        let item;

        if (source.id) {
            await Source.update(source);
            item = source.id;

        } else {
            item = await Source.create(source);
        }

        await SourceRepeat.delete(item);

        req.body.headersdata.forEach(async element => {
            const sourceRepeat = new SourceRepeat({
                headerKey: element.headerKey,
                headerValue: element.headervalue,
                sourceId: item
            });
            await SourceRepeat.create(sourceRepeat);
        });

        res.status(200).send(true);
    }
    catch (err) {
        res.status(500).send(err);
    }
};

exports.getSourceList = async (req, res) => {
    try {
        let sourcesDTO = [];
        const sources = await Source.getSources(req.user.id);
        sources.forEach(element => {
            sourcesDTO.push(
                {
                    name: element.source_name,
                    id: element.id
                }
            )
        })
        res.send(sourcesDTO);
    }
    catch (err) {
        res.status(500).send(err);
    }
}

exports.testSource = async (req, res) => {
    try {
        res.send(true);
    }
    catch (err) {
        res.status(500).send(err);
    }
}

exports.getSource = async (req, res) => {
    try {
        let sourcesDTO;
        const sources = await Source.getSourcesAndSourcesRepeat(req.query.sourceId);
        const element = sources[0];

        sourcesDTO = {
            sourceId: element.id,
            sourceName: element.source_name,
            dataUrl: element.endpoint_url,
            dataMethod: { id: element.method, name: element.method },
            body: element.body,
            headersdata: sources.map((e) => {
                return { headerKey: e.Key, headervalue: e.Value }
            }
            ),
            timeelementsettings: [
                {
                    pagination_timeelement_rolling_frequency: element.rolling_frequency,
                    pagination_timeelement_rolling_time_format: element.rolling_time_format,
                    pagination_timeelement_today_format: element.today_format,
                    pagination_timeelement_yesterday_format: element.yesterday_format
                }
            ],
            pipelinesettings: [{
                pipeline_frequency_schedule: element.schedule,
                pipeline_frequencyinterval: element.interval
            }],
            pipelinetype: { id: element.schedule ? 'schedule' : 'interval', name: element.schedule ? 'Schedule' : 'Interval' },
            authenticationtype: { id: element.authentication_type, name: element.authentication_type },
            authenticationsettings: [{
                oauth_refresh_token_endpoint_url: element.refresh_token_endpoint_url,
                oauth_refresh_token_endpoint_header: element.refresh_token_endpoint_header,
                oauth_refresh_token_endpoint_body: element.refresh_token_endpoint_body,
                oauth_refresh_token_endpoint_method: element.refresh_token_endpoint_method,
                auth_Username: element.username,
                auth_password: element.password
            }],
            paginationtype: { id: element.pagination_type, name: element.pagination_type },
            paginationsettings: [
                {
                    pagination_cursor_key: element.cursor_key,
                    pagination_user_key: element.user_key,
                    pagination_user_key_url: element.user_key_url,
                    pagination_param_for_body_update: element.pagination_param_for_body_update
                }
            ]
        }

        res.send(sourcesDTO);
    }
    catch (err) {
        res.status(500).send(err);
    }
};


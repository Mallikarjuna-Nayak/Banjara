const intBridge = require("../models/integrationBridge.model");
const ansible = require('node-ansible');
const catalogue_hash = require("../helpers/catalogue");
const { exec } = require("child_process");

/**
 * Purpose: Get all Integration Bridge data in the request
 * Author: Mallikarjuna Nayak
 * Date: 07-04-2022
 */
exports.getAllIntBridge = async (req, res) => {
  try {
	  const cnt = await intBridge.getTotalIntBridge();
      const rows = await intBridge.getAllIntBridge(req.body.min, req.body.max, cnt, req.body.sort, req.body.order, req.body.q);
      res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }  
}
/**
 * Purpose: Add Integration Bridge data in the request
 * Author: Mallikarjuna Nayak
 * Date: 07-04-2022
 */
exports.createIntBridge = async (req, res) => {
    try {
		const rows = await intBridge.createIntBridge(req.body);
        if(rows) {
          let data = {msg:"Record inserted successfully"};
		  res.send(data);
        }
        res.status(200).send(rows);
	} catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get Integration Bridge data to edit by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 07-04-2022
 */
exports.editIntBridge = async (req, res) => {
    try {
		const rows = await intBridge.editIntBridge(req.body.id);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get Integration Bridge data to update by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 07-04-2022
 */
exports.updateIntBridge = async (req, res) => {
    try {
        const rows = await intBridge.updateIntBridge(req.body);
        if(rows)
		{
			let data = {msg:"Record has been updated successfully"};
			res.send(data);
		}
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Delete Integration Bridge data with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 07-04-2022
 */
exports.deleteIntBridge = async (req, res) => {
  try {
	  const rows = await intBridge.deleteIntBridge(req.params.id);
    if(rows)
	  {
		  let data = {msg:"Record has been deleted"};
		  res.send(data);
	  }
  } catch (error) {
      res.status(400).send(error);
  }
}

exports.getInstance = async (req, res) => {
    try {
        const rows = await intBridge.getInstance();
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.editInstance = async (req, res) => {
    try {
		const rows = await intBridge.editInstance(req.body.id);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.updateInstance = async (req, res) => {
    try {
        const rows = await intBridge.updateInstance(req.body);
        if(rows)
		{
			let data = {msg:"Record has been updated successfully"};
			res.send(data);
		}
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.getPostmanData = async (req, res) => {
    try {
		const rows = await intBridge.getPostmanData(req.body.id);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.startService = async (req, res) => {
	exec("sudo ansible bizdata-dev1 -m shell -a \"sudo systemctl start "+req.body.serviceFileName+"\"", (error, stdout, stderr) => {
        let msg = 'Unable to start the service.';
        if(stdout.includes('| CHANGED |')) {
            let storeCode = intBridge.setServiceStatus(1, req.body.id);
            msg = 'Service started successfully.';
        }
        let data = {"msg": msg, "statusCode":1};
		res.status(200).send(data);

	});
}

exports.stopService = async (req, res) => {
	exec("sudo ansible bizdata-dev1 -m shell -a \"sudo systemctl stop "+req.body.serviceFileName+"\"", (error, stdout, stderr) => {
        let msg = 'Unable to stop the service.';
        if(stdout.includes('| CHANGED |')) {
            let storeCode = intBridge.setServiceStatus(0, req.body.id);
            msg = 'Service stopped successfully.';
        }
        let data = {"msg": msg, "statusCode":0};
		res.status(200).send(data);
	});
}

exports.refreshService = async (req, res) => {
	try {
		const rows = await intBridge.refreshService(req.body.id);
        let data = {"msg": "Service has been refreshed successfully"};
		res.status(200).send(data);
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.getServiceStatus = async (req, res) => {
	exec("sudo ansible bizdata-dev1 -m shell -a \"sudo systemctl status "+req.body.serviceFileName+"\"", (error, stdout, stderr) => {
        let msg = 'Unable to get the service status. Please try again.';
        let statusCode = 2;
        if(stdout.includes('Active: inactive (dead)')) {
            msg = 'Service is in stopped mode.';
            statusCode = 0;
        }
        if(stdout.includes('Active: active (running)')) {
            msg = 'Service is in start mode.';
            statusCode = 1;
        }
        let data = {"msg": msg, "statusCode":statusCode};
		res.status(200).send(data);
	});
}
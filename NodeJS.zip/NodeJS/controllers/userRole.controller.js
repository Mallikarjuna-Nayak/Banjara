const UserRole = require("../models/userRole.model");

/**
 * Purpose: Get all User role data in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.userRoles = async (req, res) => {
  try {
	  const cnt = await UserRole.getTotaluserRoles();
      const rows = await UserRole.userRoles(req.body.min, req.body.max, cnt, req.body.sort, req.body.order);
      res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }  
}
/**
 * Purpose: Add user role data in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.createUserRole = async (req, res) => {
    try {
        const rows = await UserRole.createUserRole(req.body);
        if(rows) {
          let data = {msg:"Record inserted successfully"};
				  res.send(data);
        }
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get user role data to edit by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.editUserRole = async (req, res) => {
    try {
		const rows = await UserRole.editUserRole(req.body.id);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get user role data to update by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.updateUserRole = async (req, res) => {
    try {
        const rows = await UserRole.updateUserRole(req.body);
        if(rows)
		{
			let data = {msg:"Record has been updated"};
				res.send(data);
		}
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Delete User role with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.deleteUserRole = async (req, res) => {
  try {
	  const rows = await UserRole.deleteUserRole(req.params.id);
    if(rows)
	  {
		  let data = {msg:"Record has been deleted"};
		  res.send(data);
	  }
  } catch (error) {
      res.status(400).send(error);
  }
}

/**
 * Purpose: Get all permissoin data in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.allPermissions = async (req, res) => {
  try {
	  const cnt = await UserRole.getTotalPermissions();
      const rows = await UserRole.allPermissions(req.body.min, req.body.max, cnt, req.body.sort, req.body.order);
      res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }  
}
/**
 * Purpose: Add permission data in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.createPermission = async (req, res) => {
    try {
        const rows = await UserRole.createPermission(req.body);
        if(rows) {
          let data = {msg:"Record inserted successfully"};
				  res.send(data);
        }
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get permission data to edit by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.editPermission = async (req, res) => {
    try {
		const rows = await UserRole.editPermission(req.body.id);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get permission data to update by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.updatePermission = async (req, res) => {
    try {
        const rows = await UserRole.updatePermission(req.body);
        if(rows)
		{
			let data = {msg:"Record has been updated"};
				res.send(data);
		}
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Delete permission with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.deletePermission = async (req, res) => {
  try {
	  const rows = await UserRole.deletePermission(req.params.id);
    if(rows)
	  {
		  let data = {msg:"Record has been deleted"};
		  res.send(data);
	  }
  } catch (error) {
      res.status(400).send(error);
  }
}

/**
 * Purpose: Get all role based permissoin data in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
 /*
exports.allRolePermissions = async (req, res) => {
  try {
	  const cnt = await UserRole.getTotalRolePermissions();
      const rows = await UserRole.allRolePermissions(req.body.min, req.body.max, cnt, req.body.sort, req.body.order);
      res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }  
}
*/

/**
 * Purpose: Add role based permission data in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.createRolePermission = async (req, res) => {
    try {
        const rows = await UserRole.createRolePermission(req.body);
        if(rows) {
          let data = {msg:"Record inserted successfully"};
				  res.send(data);
        }
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get role based permission data to edit by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.editRolePermission = async (req, res) => {
    try {
		const rows = await UserRole.editRolePermission(req.body.id);
        res.status(200).send(rows);
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Get role based permission data to update by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.updateRolePermission = async (req, res) => {
    try {
        const rows = await UserRole.updateRolePermission(req.body);
        if(rows)
		{
			let data = {msg:"Record has been updated"};
				res.send(data);
		}
    } catch (error) {
        res.status(400).send(error);
    }
}
/**
 * Purpose: Delete role based permission with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 04-03-2022
 */
exports.deleteRolePermission = async (req, res) => {
  try {
	  const rows = await UserRole.deleteRolePermission(req.params.id);
    if(rows)
	  {
		  let data = {msg:"Record has been deleted"};
		  res.send(data);
	  }
  } catch (error) {
      res.status(400).send(error);
  }
}


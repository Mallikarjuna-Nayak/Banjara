const User = require("../models/user.model.js");
const mail = require("../helpers/email");
const config = require("../config/config");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const { NotFoundError } = require("../helpers/utility");
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

/**
 * Register New User
 * Author: Piklu Chakraborty
 */
exports.register = async (req, res) => {
  try {
    //check if user exists
    const existingUser = await User.getUser(req.body.email);
    if (existingUser) {
      res.status(400).send("User already registered");
      return;
    }

    //Hash password
    // const salt = await bcrypt.genSalt(10);
    // var generatedPassword = Math.random().toString(36).slice(-8);
    // const hasPassword = await bcrypt.hash(generatedPassword, salt);

    const trial = req.body.freeTrialMode ? 1 : 0;
    const tokenExpiry = "0.5h";
    const currentDateTime = new Date();
    // var subscriptionEndDate = new Date(); // Now
    // subscriptionEndDate.setDate(subscriptionEndDate.getDate() + 30);


    // Create an user object
    const user = new User({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      email: req.body.email,
      phone: req.body.phone,
      jobTitle: req.body.jobTitle,
      employee: req.body.employee,
      company: req.body.company,
      country: req.body.country,
      trail: trial,
      currentDateTime: currentDateTime,
      // subscriptionEndDate: subscriptionEndDate,
      create_ip_address: req.body.create_ip_address,
      update_ip_address: req.body.create_ip_address
      // password: hasPassword
    });

    // Save User in the database
    const response = await User.create(user);
    user.id = response.ID;
    user.register_date = response.register_date;
    const token = jwt.sign(
      { id: response.organization_id, email: user.work_email },
      config.TOKEN_SECRET,
      { expiresIn: tokenExpiry }
    );
    user.token = token;
    user.expTime = new Date(jwt.decode(token).exp * 1000);
    delete user.password;
    const origin = req.get('origin');
    // const origin = "http://localhost:4200";
    const url = `${origin}/#/verify?data=${token}`;
    await mail.emailVerify(user, url);
    res.send(user);
  } catch (err) {
    res.status(500).send(err);
  }
};

/**
 * Get Verification Code
 * Author: Piklu Chakraborty
 */
exports.getVerificationCode = async (req, res) => {
  try {
    let data = {
      email: req.body.email,
      id: req.body.id,
    };
    const result = await User.getVerificationCode(data);
    let response = {
      code: result.verification_code,
    };
    res.status(200).send(response);
  } catch (error) {
    res.status(404).send(error);
  }
};

/**
 * Send and Generate New Verification Code
 * Author: Piklu Chakraborty
 */
exports.sendVerificationCode = async (req, res) => {
  try {
    const min_number = 100000;
    const max_number = 999990;
    const vcode =
      Math.floor(Math.random() * (max_number - min_number + 1)) + min_number;
    let data = {
      email: req.body.email,
      id: req.body.id,
      vcode,
    };
    const result = await User.setVerificationCode(data);
    if (result == true) {
      await mail.emailVerificationCode(req.body.email, vcode);
      let data = {
        msg: "Verification code has been sent to your registered email",
      };
      res.status(200).send(data);
    }
  } catch (error) {
    res.status(404).send(error);
  }
};

/**
 * Set New Password
 * Author: Piklu Chakraborty
 */
exports.setNewPassword = async (req, res) => {
  try {
    //Hash password
    const salt = await bcrypt.genSalt(10);
    const hasPassword = await bcrypt.hash(req.body.password, salt);
    let obj = {
      id: req.body.id,
      email: req.body.email,
      questId: req.body.questId,
      answer: req.body.answer,
      password: hasPassword,
    };
    await User.setNewPassword(obj);
    let data = {
      msg: "Password has been set",
    };
    res.status(200).send(data);
  } catch (error) {
    res.status(400).send(error);
  }
};

/**
 * Get Security Questions
 * Author: Piklu Chakraborty
 */
exports.getSecurityQuestions = async (req, res) => {
  try {
    const questions = await User.fetchQuestions();
    res.status(200).send(questions);
  } catch (error) {
    res.status(400).send(error);
  }
};

/**
 * Subscribe for Free Trial Users
 * Author: Piklu Chakraborty
 */
exports.subscribe = async (req, res) => {
  try {
    const currentDateTime = new Date();
    var subscriptionEndDate = new Date(); // Now
    subscriptionEndDate.setDate(subscriptionEndDate.getDate() + 180);

    let payload = {
      freeTrialMode: 0,
      email: req.user.email,
      id: req.user.id,
      currentDateTime,
      subscriptionEndDate
    };
    let response = await User.subscribe(payload);
    let data = {
      subscription_start_date: response.subscription_start_date,
      subscription_end_date: response.subscription_end_date,
      subscription_number: response.subscription_number
    };
    res.status(200).send(data);
  } catch (error) {
    res.status(400).send(error);
  }
};

/**
 * Login
 * Author: Piklu Chakraborty
 */
exports.login = async (req, res) => {
  try {
    // Check user exist
    const user = await User.login(req.body.email);
    const org = await User.orginationInfo(req.body.email);
    const rememberMe = req.body.remember;
    const tokenExpiry = rememberMe ? "7d" : "0.5h";
    let daysDifference;
    let package;

    if(org.free_trial_mode == 1) {
      //Free trial user
      let date = new Date(org.created_date);
      let subscriptionTimestamp = date.getTime();
      let currentTimestamp = Date.now();
      var difference = currentTimestamp - subscriptionTimestamp;
      daysDifference = 30 - Math.floor(difference / 1000 / 60 / 60 / 24);
      package = "Free Trial";
    } else if(org.free_trial_mode == 0) {
      //Subscribed user
      let date = new Date(org.subscription_end_date);
      let today = Date.now();
      if(today > date) {
        daysDifference = 0;
      }
      package = "Subscription";
    }

    if (user) {
      const validPass = await bcrypt.compare(req.body.password, user.password);
      if (!validPass)
        return res.status(400).send("Username or Password is wrong. Please re-check the credentials");

      // Create and assign token
      const token = jwt.sign(
        { id: user.ID, email: user.email },
        config.TOKEN_SECRET,
        { expiresIn: tokenExpiry }
      );
      if (daysDifference <= 0) {
        let data = {
          msg: "Your "+package+" has been expired",
        };
        res.send(data);
      } else {
        let data = {
          token: token,
          id: user.ID,
          work_email: user.email,
          first_name: user.first_name,
          last_name: user.last_name,
          free_trial_mode: org.free_trial_mode == 1 ? true : false,
          job_title: org.job_title,
          company_logo: Number(org.company_logo),
          profile_image: Number(user.profile_image),
          free_trail_days_left: daysDifference,
          expTime: new Date(jwt.decode(token).exp * 1000),
        };
        if (org.free_trial_mode == 0) {
          delete data.free_trail_days_left;
        }
        res.header("auth-token", token).send(data);
      }

      // res.send("Logged IN");
    }
  } catch (err) {
    if (err instanceof NotFoundError) {
      res.status(401).send(`Username or Password is wrong. Please re-check the credentials`);
    } else {
      let error_data = {
        entity: "User",
        model_obj: { param: req.params, body: req.body },
        error_obj: err,
        error_msg: err.message,
      };
      res.status(500).send("Error retrieving User");
    }
  }
};

// Access auth users only
exports.authuseronly = (req, res) => {
  res.send(
    "Hey,You are authenticated user. So you are authorized to access here."
  );
};

// Admin users only
exports.adminonly = (req, res) => {
  res.send("Success. Hellow Admin, this route is only for you");
};

exports.validateLoggedInSession = async (req, res) => {
  const user = await User.login(req.user.email);
  res.send({
    id: user.ID,
    email: user.email,
    first_name: user.first_name,
    last_name: user.last_name,
    expTime: new Date(req.user.exp * 1000),
  });
};

exports.refreshToken = async (req, res) => {
  const user = await User.login(req.user.email);

  const rememberMe = req.query.rememberMe == 'true' ? true : false;
  const tokenExpiry = rememberMe ? "7d" : "0.5h";
  const token = jwt.sign(
    { id: user.ID, email: user.email },
    config.TOKEN_SECRET,
    { expiresIn: tokenExpiry }
  );

  res.header("auth-token", token).send({
    token: token,
    id: user.ID,
    email: user.email,
    first_name: user.first_name,
    last_name: user.last_name,
    expTime: new Date(jwt.decode(token).exp * 1000),
  });
};

exports.forgotPassword = async (req, res) => {
  try {
    // Check user exist
    const user = await User.login(req.body.email);
    const tokenExpiry = "0.5h";

    if (user) {
      // Create and assign token
      const token = jwt.sign(
        { id: user.ID, email: user.email },
        config.PASSWORD_RESET_TOKEN_SECRET,
        { expiresIn: tokenExpiry }
      );

      const origin = req.get('origin');
      //const origin = "http://localhost:4200";
      const url = `${origin}/#/reset-password?token=${token}`;
      await mail.emailPasswordResetLink(user, url);
      res.send(true);
    }
  } catch (err) {
    if (err instanceof NotFoundError) {
      res.status(400).send(`User doesn't exists`);
    } else {
      res.status(500).send("Error retrieving User");
    }
  }
};

exports.changePassword = async (req, res) => {
  try {
    // Check user exist
    const user = await User.login(req.user.email);

    if (user) {
      const salt = await bcrypt.genSalt(10);
      const hasPassword = await bcrypt.hash(req.body.password, salt);
      await User.changePassword(req.user.id, hasPassword);
      res.status(200).send({ message: "Password successfully changed" });
    }
  } catch (err) {
    if (err instanceof NotFoundError) {
      res.status(400).send(`User doesn't exists`);
    } else {
      res.status(500).send("Error changing password");
    }
  }
};

exports.resetPassword = async (req, res) => {
  try {
    // Check user exist
    const user = await User.validateUser(req.body.email, req.body.id);

    if (user) {
      const salt = await bcrypt.genSalt(10);
      const hasPassword = await bcrypt.hash(req.body.password, salt);
      await User.changePassword(req.body.id, hasPassword);
      res.status(200).send({ msg: "Password successfully changed" });
    } else {
      res.status(400).send({ msg: "Invalid user" });
    }
  } catch (err) {
    if (err instanceof NotFoundError) {
      res.status(400).send(`User doesn't exists`);
    } else {
      res.status(500).send("Error changing password");
    }
  }
};

exports.changeExistingPassword = async (req, res) => {
  try {
    // Check user exist
    const user = await User.login(req.user.email);

    if (user) {
      const validPass = await bcrypt.compare(
        req.body.currentPassword,
        user.password
      );
      if (!validPass) return res.status(400).send("current password is wrong");

      const salt = await bcrypt.genSalt(10);
      const hasPassword = await bcrypt.hash(req.body.newPassword, salt);
      await User.changePassword(req.user.id, hasPassword);
      res.status(200).send({ message: "Password successfully changed" });
    }
  } catch (err) {
    if (err instanceof NotFoundError) {
      res.status(400).send(`User doesn't exists`);
    } else {
      res.status(500).send("Error changing password");
    }
  }
};

exports.getUserProfileImage = async (req, res) => {
  try {
    const rows = await User.getUserProfileImage(req.body.img_collection_id);
    res.status(200).send(rows);
  } catch (error) {
    res.status(404).send(error);
  }
}

exports.saveProfileImage = async (req, res) => {
  try {
    const buffer = fs.readFileSync("uploads/" + req.file.filename);
    var bufferBase64 = buffer.toString("base64");
    const rows = await User.saveProfileImage(req.user.id, bufferBase64);
    if (rows) {
      let data = { "profileImage_hash": bufferBase64 };
      res.send(data);
    }
  } catch (error) {
    res.status(404).send(error);
  }
}

exports.updateProfileImage = async (req, res) => {
  try {
    const buffer = fs.readFileSync("uploads/" + req.file.filename);
    var bufferBase64 = buffer.toString("base64");
    const rows = await User.updateProfileImage(req.body.img_collection_id, bufferBase64);
    if (rows) {
      let data = { "profileImage_hash": bufferBase64 };
      res.send(data);
    }
  } catch (error) {
    res.status(404).send(error);
  }
}

exports.deleteUserProfileImage = async (req, res) => {
  try {
    const rows = await User.deleteUserProfileImage(req.params.userId, req.params.collectionId);
    if (rows) {
      let data = {
        msg: "Profile image has been deleted",
      };
      res.send(data);
    }
  } catch (error) {
    res.status(400).send(error);
  }
}

exports.deleteUser = async (req, res) => {
  try {
    const status = await User.deleteUser(req.params.id);
    if (status) {
      let data = { msg: "Record has been deleted successfully" };
      res.send(data);
    }
  } catch (err) {
    res.status(500).send("Error in deleting user");
  }
};
/**
 * Purpose: Add or create a new user data in the request
 * Author: Mallikarjuna Nayak
 * Date: 16-02-2022
 */
exports.createNewUserApi = async (req, res) => {
  try {
    const salt = await bcrypt.genSalt(10);
    const hasPassword = await bcrypt.hash(req.body.password, salt);
    const rows = await User.createNewUserApi(req.body, hasPassword);
    if (rows) {
      let data = { msg: "New User has been created" };
      res.send(data);
    }
    res.status(200).send(rows);
  } catch (error) {
    res.status(400).send(error);
  }
};
/**
 * Purpose: Get users list data in the request
 * Author: Mallikarjuna Nayak
 * Date: 11-02-2022
 */
exports.getAllUsers = async (req, res) => {
  try {
    let cnt = await User.getAllUsersCount();
    const status = await User.getAllUsers(req.body.min, req.body.max, cnt, req.body.sort, req.body.order, req.body.q);
    res.send(status);
  } catch (err) {
    res.status(500).send("Error in getting users data");
  }
};
/**
 * Purpose: Get user data to edit by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 11-02-2022
 */
exports.userApiEdit = async (req, res) => {
  try {
    let user_selected_grp = await User.getUserSelectedGroups(req.body.ID);
    const rows = await User.userApiEdit(req.body.ID, user_selected_grp);
    res.status(200).send(rows);
  } catch (error) {
    res.status(400).send(error);
  }
};

/**
 * Purpose: Update User details with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 11-02-2022
 */
exports.updateApiUser = async (req, res) => {
  try {
    var hasPassword = '';
    if (req.body.password) {
      const salt = await bcrypt.genSalt(10);
      hasPassword = await bcrypt.hash(req.body.password, salt);
    }
    const rows = await User.updateApiUser(req.body, hasPassword);
    if (rows) {
      let data = { msg: "Record has been updated" };
      res.send(data);
    }
  } catch (error) {
    res.status(400).send(error);
  }
}


/**
 * Purpose: Get all User_group data in the request
 * Author: Mallikarjuna Nayak
 * Date: 14-02-2022
 */
exports.getAllUserGroups = async (req, res) => {
  try {
    let sort = req.body.sort ? req.body.sort : "";
    let order = req.body.order ? req.body.order : "";
    let search = req.body.q ? req.body.q : "";
    const cnt = await User.getTotalUserGroups();
    const rows = await User.getAllUserGroups(req.body.min, req.body.max, cnt, sort, order, search);
    res.status(200).send(rows);
  } catch (error) {
    res.status(400).send(error);
  }
}
/**
 * Purpose: Add user_group data in the request
 * Author: Mallikarjuna Nayak
 * Date: 14-02-2022
 */
exports.addUserGroups = async (req, res) => {
  try {
    const rows = await User.addUserGroups(req.body);
    if (rows) {
      let data = { msg: "New User Group is created" };
      res.send(data);
    }
    res.status(200).send(rows);
  } catch (error) {
    res.status(400).send(error);
  }
}
/**
 * Purpose: Get user_group data to edit by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 14-02-2022
 */
exports.editUserGroups = async (req, res) => {
  try {
    let user_assoc_grp = await User.getUserAssocGroups(req.body.ID);
    const rows = await User.editUserGroups(req.body.ID, user_assoc_grp);
    res.status(200).send(rows);
  } catch (error) {
    res.status(400).send(error);
  }
}
/**
 * Purpose: Get user_group data to update by specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 14-02-2022
 */
exports.updateUserGroups = async (req, res) => {
  try {
    const rows = await User.updateUserGroups(req.body);
    if (rows) {
      let data = { msg: "Record has been updated" };
      res.send(data);
    }
  } catch (error) {
    res.status(400).send(error);
  }
}
/**
 * Purpose: Delete User group with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 14-02-2022
 */
exports.deleteUserGroups = async (req, res) => {
  try {
    const rows = await User.deleteUserGroups(req.params.ID);
    if (rows) {
      let data = { msg: "Record has been deleted" };
      res.send(data);
    }
  } catch (error) {
    res.status(400).send(error);
  }
}

exports.setLogoImage = async (req, res) => {
  try {
    console.log(req.form);
    res.send(req.form);
  } catch (error) {
    res.status(400).send(error);
  }
}

/**
 * Purpose: Profile Change password request
 * Author: Mallikarjuna Nayak
 * Date: 29-03-2022
 */
exports.changeUserPassword = async (req, res) => {
  try {
    const user = await User.getUserPassword(req.user.id);
    const current_hasPassword = req.body.current_password;
    const salt = await bcrypt.genSalt(10);
    const new_hasPassword = await bcrypt.hash(req.body.new_password, salt);
    bcrypt.compare(current_hasPassword, user.password, function (err, result) {
      if (result) {
        const rows = User.changeUserPassword(new_hasPassword, req.user.id);
        if (rows) {
			mail.changeUserPasswordMailConform(user.first_name, user.last_name, user.email);
			let data = { msg: "Your Password has been changed successfully" };
			res.status(200).send(data);
        }
      }
      else {
        // let data = { msg: "Your current password is invalid" };
        res.status(400).send("Your current password is invalid");
      }
    });
  } catch (error) {
    res.status(400).send(error);
  }
}
const { NotFoundError } = require("../helpers/utility");
const Target = require("../models/target.model.js");
const TargetRepeat = require("../models/target-repeat.model");

exports.saveTarget = async (req, res) => {
    try {
        const target = new Target(req.body, req.user.id);
        let item;

        if (target.id) {
            await Target.update(target);
            item = target.id;

        } else {
            item = await Target.create(target);
        }

        await TargetRepeat.delete(item);

        req.body.headersdata.forEach(async element => {
            const targetRepeat = new TargetRepeat({
                headerKey: element.headerKey,
                headerValue: element.headervalue,
                sourceId: item
            });
            await TargetRepeat.create(targetRepeat);
        });

        res.status(200).send(true);
    }
    catch (err) {
        res.status(500).send(err);
    }
};

exports.getTargetList = async (req, res) => {
    try {
        let targetDTO = [];
        const sources = await Target.getTargets(req.user.id);
        sources.forEach(element => {
            targetDTO.push(
                {
                    name: element.target_name,
                    id: element.id
                }
            )
        })
        res.send(targetDTO);
    }
    catch (err) {
        res.status(500).send(err);
    }
}

exports.getTarget = async (req, res) => {
    try {
        let targetDTO;
        const sources = await Target.getTargetsAndTargetsRepeat(req.query.targetId);
        const element = sources[0];

        targetDTO = {
            sourceId: element.id,
            targetName: element.target_name,
            dataUrl: element.rest_url,
            dataMethod: { id: element.method, name: element.method },
            //body: element.body,
            headersdata: sources.map((e) => {
                return { headerKey: e.key1, headervalue: e.value1 }
            }
            ),
            authenticationtype: { id: element.authorization_type, name: element.authorization_type },
            authenticationsettings: [{
                // oauth_refresh_token_endpoint_url: element.refresh_token_endpoint_url,
                // oauth_refresh_token_endpoint_header: element.refresh_token_endpoint_header,
                // oauth_refresh_token_endpoint_body: element.refresh_token_endpoint_body,
                // oauth_refresh_token_endpoint_method: element.refresh_token_endpoint_method,
                auth_Username: element.user_name,
                auth_password: element.password
            }],
            contentsettings: [{
                contentType: element.content_type,
                messageFormat: element.message_format
            }],
            connectionsettings: [{
                ObjectName: { id: element.object_name },
                maxConnection: element.max_connection
            }]
            //paginationtype: { id: element.pagination_type, name: element.pagination_type },
            // paginationsettings: [
            //     {
            //         pagination_cursor_key: element.cursor_key,
            //         pagination_user_key: element.user_key,
            //         pagination_user_key_url: element.user_key_url,
            //         pagination_param_for_body_update: element.pagination_param_for_body_update
            //     }
            // ]
        }

        res.send(targetDTO);
    }
    catch (err) {
        res.status(500).send(err);
    }
};


const express = require("express");
const compression = require("compression");
const helmet = require("helmet");

const app = express();

app.use(compression());
app.use(helmet());

app.use(express.json());

app.use(function (req, res, next) {
  // Website you wish to allow to connect
  res.setHeader("Access-Control-Allow-Origin", "*");

  // Request methods you wish to allow
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, OPTIONS, PUT, PATCH, DELETE"
  );

  // Request headers you wish to allow
  res.setHeader("Access-Control-Allow-Headers", "*");

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader("Access-Control-Allow-Credentials", true);

  // Pass to next layer of middleware
  next();
});

// Import Routes
const userRoute = require("./routes/user-route");
const apiCatalogueRoute = require("./routes/api-catalogue-route");
const sourceRoute = require("./routes/source-route");
const targetRoute = require("./routes/target-route");
const organizationRoute = require("./routes/organization-route");
const countriesRoute = require("./routes/countries-route");

const userRole = require("./routes/user-role");
const integrationBridge = require("./routes/integrationBridge-route");

// Route Middlewares
app.use("/api/users", userRoute);
app.use("/api/catalogue", apiCatalogueRoute);
app.use("/api/source", sourceRoute);
app.use("/api/target", targetRoute);
app.use("/api/organization", organizationRoute);
app.use("/api/countries", countriesRoute);

app.use("/api/roles", userRole);
app.use("/api/integrationBridge", integrationBridge);



const port = process.env.PORT || 3300;
app.listen(port, () => console.log(`Server is running on ${port}`));


exports.catalogue = function (data) {
    const api_url = data.endpoint_url;
    const api_method = data.endpoint_method;
    // const api_token = data.api_endpoint_token;
    const api_body_raw = data.endpoint_body_raw; // Objects[key, value]
    const api_param = (data.endpoint_params_raw) ? data.endpoint_params_raw : ""; // Objects[key, value]
    const api_headers = (data.endpoint_headers) ? data.endpoint_headers : ""; // Objects[key, value]
    const api_authentication_type = data.authentication_type;

    const input_structure_json = {
        endpoint_url: api_url,
        endpoint_method: api_method
    }

    input_structure_json['endpoint_headers']= api_headers;
    input_structure_json['endpoint_body_raw']= api_body_raw;
    input_structure_json['authentication_type'] = api_authentication_type;
    input_structure_json['authentication_token'] = data.authentication_token;
    input_structure_json['username'] = data.username;
    input_structure_json['password'] = data.password;
    input_structure_json['refresh_token_endpoint_url'] = data.refresh_token_endpoint_url;
    input_structure_json['refresh_token_endpoint_header'] = data.refresh_token_endpoint_header;
    input_structure_json['refresh_token_endpoint_method'] = data.refresh_token_endpoint_method;
    input_structure_json['refresh_token_endpoint_body'] = data.refresh_token_endpoint_body;
    input_structure_json['refresh_token_endpoint_params'] = data.refresh_token_endpoint_params;
    input_structure_json['query_type_auth'] = ':form';


    // // The id for related authentication_type {1 = No Auth}, {2 = API Key}, {3 = Bearer Token}, {4 = Basic Auth}, {5 = OAuth 1.0}, {6 = OAuth 2.0}
    // if(api_authentication_type.id == 1){
    //     input_structure_json['authentication_type'] = api_authentication_type.type
    // }else if(api_authentication_type.id == 3){
    //     input_structure_json['authentication_type'] = api_authentication_type.type,
    //     input_structure_json['authentication_token'] = "Bearer " + data.authentication_token;
    // }else if(api_authentication_type.id == 4){
    //     input_structure_json['authentication_type'] = api_authentication_type.type,
    //     input_structure_json['authentication_username'] = data.authentication_username,
    //     input_structure_json['authentication_password'] = data.authentication_password
    // }
    
    var end_param = "";
    if(api_param) {
        if(Object.keys(api_param).length !== 0){
            input_structure_json['query_type_raw'] = ":json";
            input_structure_json['endpoint_param_raw'] = api_param;
        }
        //end_param = "{${this.endpoint_hashing(input_structure_json.endpoint_param_raw)}\n\t\t}";
        end_param = `{${this.endpoint_hashing(input_structure_json.endpoint_param_raw)}\n\t\t}`;
    } else {
        input_structure_json['query_type_raw'] = ":json";
        input_structure_json['endpoint_param_raw'] = "";
    }

    let json = {
        "input": {
            "bizdata_rest": input_structure_json
        }
    };

    const input_structure_hash = 
    `{ 
    input {
    \t bizdata_rest {
    \t\t pre_request_script => ''
    \t\t endpoint_url => "${input_structure_json.endpoint_url}"
    \t\t endpoint_headers => '{${this.endpoint_hashing(input_structure_json.endpoint_headers)}\n\t\t}'
    \t\t endpoint_method => "${input_structure_json.endpoint_method.method}"
    \t\t endpoint_body_raw => '{${this.endpoint_hashing(input_structure_json.endpoint_body_raw)}\n\t\t}'
    \t\t endpoint_param_raw => '${end_param}'
    \t\t query_type_raw => "${input_structure_json.query_type_raw}"
    \t\t authentication_type => "${input_structure_json.authentication_type.type}"
    \t\t username => "${input_structure_json.username}"
    \t\t password => "${input_structure_json.password}"
    \t\t refresh_token_endpoint_url => "${input_structure_json.refresh_token_endpoint_url}"
    \t\t refresh_token_endpoint_header  => "${input_structure_json.refresh_token_endpoint_header}"
    \t\t refresh_token_endpoint_method  => "${input_structure_json.refresh_token_endpoint_method.method}"
    \t\t refresh_token_endpoint_body  => "${input_structure_json.refresh_token_endpoint_body}"
    \t\t refresh_token_endpoint_params  => "${input_structure_json.refresh_token_endpoint_params}"
    \t\t query_type_auth  => "${input_structure_json.query_type_auth}"
    \t\t }
    \t } 
    }`

    let final_data = {
        input_structure_hash,
        input_structure_json: json
    }
    return final_data;
}

exports.endpoint_hashing = function(obj){
    let temp_arr = [];
	if(Array.isArray(obj))
	{
		obj.forEach(v => { temp_arr.push((v["key"]+ " => "+v["value"]+" ")) });
	}else{
		for (const [key, value] of Object.entries(obj)) {
		   let e = `"${key}" => "${value}"`;
		   temp_arr.push(e);
		}
	}
	return temp_arr.toString();
	
	/*
	for (const [key, value] of Object.entries(obj)) {
       let e = `\n\t\t\t"${key}" => "${value}"`;
       temp_arr.push(e);
    }
    return temp_arr.toString();
	*/

}

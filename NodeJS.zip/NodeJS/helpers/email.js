const nodemailer = require("nodemailer");
const config = require("../config/config");
var handlebars = require('handlebars');
var fs = require('fs');
const fsPromises = fs.promises;

exports.email = async function (user, password) {
    let transporter = nodemailer.createTransport({
        host: config.EMAIL_HOST,
        port: config.EMAIL_PORT,
        secure: true,
        auth: {
            user: config.COMPANY_EMAIL,
            pass: config.COMPANY_PASSWORRD
        },
    });
    const html = await fsPromises.readFile('./helpers/signup-mail/emailer.html', { encoding: 'utf-8' });

    var template = handlebars.compile(html);
    var replacements = {
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        password: password
    };
    var htmlToSend = template(replacements);
    var mailOptions = {
        from: config.COMPANY_EMAIL,
        to: user.email,
        subject: "Signup is successful",
        html: htmlToSend,
        attachments: [
            {
                filename: 'BIZDATA_02.png',
                path: __dirname + '/signup-mail/images/BIZDATA_02.png',
                cid: 'BIZDATA_02'
            },
            {
                filename: 'Bizdata.png',
                path: __dirname + '/signup-mail/images/Bizdata.png',
                cid: 'Bizdata'
            },
            {
                filename: 'Bizintel high resolution_logo-01.png',
                path: __dirname + '/signup-mail/images/Bizintel high resolution_logo-01.png',
                cid: 'Bizintel'
            },
            {
                filename: 'emailer_01.jpg',
                path: __dirname + '/signup-mail/images/emailer_01.jpg',
                cid: 'emailer_01'
            },
            {
                filename: 'emailer_04.jpg',
                path: __dirname + '/signup-mail/images/emailer_04.jpg',
                cid: 'emailer_04'
            },
            {
                filename: 'emailer_03.jpg',
                path: __dirname + '/signup-mail/images/emailer_03.jpg',
                cid: 'emailer_03'
            },
            {
                filename: 'emailer_07.jpg',
                path: __dirname + '/signup-mail/images/emailer_07.jpg',
                cid: 'emailer_07'
            },
            {
                filename: 'emailer_08.jpg',
                path: __dirname + '/signup-mail/images/emailer_08.jpg',
                cid: 'emailer_08'
            },
            {
                filename: 'emailer_09.jpg',
                path: __dirname + '/signup-mail/images/emailer_09.jpg',
                cid: 'emailer_09'
            },
            {
                filename: 'eZintegration.png',
                path: __dirname + '/signup-mail/images/eZintegration.png',
                cid: 'eZintegration'
            }
        ]
    };

    // send mail with defined transport object
    let info = await transporter.sendMail(mailOptions);
}

exports.emailVerify = async function (user, url) {
    let transporter = nodemailer.createTransport({
        host: config.EMAIL_HOST,
        port: config.EMAIL_PORT,
        secure: true,
        auth: {
            user: config.COMPANY_EMAIL,
            pass: config.COMPANY_PASSWORRD
        },
    });
    const html = await fsPromises.readFile('./helpers/verify-account-mail/emailer.html', { encoding: 'utf-8' });

    var template = handlebars.compile(html);
    var replacements = {
        email: user.work_email,
        firstName: user.first_name,
        lastName: user.last_name,
        url: url
    };
    var htmlToSend = template(replacements);
    var mailOptions = {
        from: config.COMPANY_EMAIL,
        to: user.work_email,
        subject: "Verify Account",
        html: htmlToSend,
        attachments: [
            {
                filename: 'BIZDATA_02.png',
                path: __dirname + '/verify-account-mail/images/BIZDATA_02.png',
                cid: 'BIZDATA_02'
            },
            {
                filename: 'Bizdata.png',
                path: __dirname + '/verify-account-mail/images/Bizdata.png',
                cid: 'Bizdata'
            },
            {
                filename: 'Bizintel high resolution_logo-01.png',
                path: __dirname + '/verify-account-mail/images/Bizintel_high_resolution_logo_01.png',
                cid: 'Bizintel'
            },
            {
                filename: 'Bizintel360.png',
                path: __dirname + '/verify-account-mail/images/Bizintel360.png',
                cid: 'Bizintel360'
            },
            {
                filename: 'emailer_01.jpg',
                path: __dirname + '/verify-account-mail/images/emailer_01.jpg',
                cid: 'emailer_01'
            },
            {
                filename: 'emailer_04.jpg',
                path: __dirname + '/verify-account-mail/images/emailer_04.jpg',
                cid: 'emailer_04'
            },
            {
                filename: 'emailer_03.jpg',
                path: __dirname + '/verify-account-mail/images/emailer_03.jpg',
                cid: 'emailer_03'
            },
            {
                filename: 'emailer_07.jpg',
                path: __dirname + '/verify-account-mail/images/emailer_07.jpg',
                cid: 'emailer_07'
            },
            {
                filename: 'emailer_08.jpg',
                path: __dirname + '/verify-account-mail/images/emailer_08.jpg',
                cid: 'emailer_08'
            },
            {
                filename: 'emailer_09.jpg',
                path: __dirname + '/verify-account-mail/images/emailer_09.jpg',
                cid: 'emailer_09'
            },
            {
                filename: 'eZintegration_1.jpg',
                path: __dirname + '/verify-account-mail/images/eZintegration_1.jpg',
                cid: 'eZintegration_1'
            },
            {
                filename: 'eZintegration.png',
                path: __dirname + '/verify-account-mail/images/eZintegration.png',
                cid: 'eZintegration'
            },
            {
                filename: 'eZintegrations.png',
                path: __dirname + '/verify-account-mail/images/eZintegrations.png',
                cid: 'eZintegrations'
            }
        ]
    };

    // send mail with defined transport object
    let info = await transporter.sendMail(mailOptions);
}

exports.emailVerificationCode = async function (email, vcode) {
    let transporter = nodemailer.createTransport({
        host: config.EMAIL_HOST,
        port: config.EMAIL_PORT,
        secure: true,
        auth: {
            user: config.COMPANY_EMAIL,
            pass: config.COMPANY_PASSWORRD
        },
    });
    const html = await fsPromises.readFile('./helpers/verificationCode.html', { encoding: 'utf-8' });

    var template = handlebars.compile(html);
    var replacements = {
        vcode: vcode
    };
    var htmlToSend = template(replacements);
    var mailOptions = {
        from: config.COMPANY_EMAIL,
        to: email,
        subject: "Verification code",
        html: htmlToSend
    };

    // send mail with defined transport object
    let info = await transporter.sendMail(mailOptions);
}

exports.emailPasswordResetLink = async function (user, url) {
    let transporter = nodemailer.createTransport({
        host: config.EMAIL_HOST,
        port: config.EMAIL_PORT,
        secure: true,
        auth: {
            user: config.COMPANY_EMAIL,
            pass: config.COMPANY_PASSWORRD
        },
    });
    const html = await fsPromises.readFile('./helpers/forgotPassword.html', { encoding: 'utf-8' });

    var template = handlebars.compile(html);
    var replacements = {
        url: url,
        firstName: user.first_name,
        lastName: user.last_name,
    };
    var htmlToSend = template(replacements);
    var mailOptions = {
        from: config.COMPANY_EMAIL,
        to: user.email,
        subject: "Reset your password",
        html: htmlToSend
    };

    // send mail with defined transport object
    let info = await transporter.sendMail(mailOptions);
}
/**
 * Purpose: Password change confirmation message sending to user
 * Author: Mallikarjuna Nayak
 * Date: 31-03-2022
 */
exports.changeUserPasswordMailConform = async function (firstName, lastName, email) {
    let transporter = nodemailer.createTransport({
        host: config.EMAIL_HOST,
        port: config.EMAIL_PORT,
        secure: true,
        auth: {
            user: config.COMPANY_EMAIL,
            pass: config.COMPANY_PASSWORRD
        },
    });
    const html = await fsPromises.readFile('./helpers/changeUserPasswordMailConfirm.html', { encoding: 'utf-8' });

    var template = handlebars.compile(html);
    var replacements = {
		firstName: firstName,
		lastName: lastName,
        msg: "Your Password has been changed successfully and please login with your new password."
    };
    var htmlToSend = template(replacements);
    var mailOptions = {
        from: config.COMPANY_EMAIL,
        to: email,
        subject: "Password Change",
        html: htmlToSend
    };

    // send mail with defined transport object
    let info = await transporter.sendMail(mailOptions);
}

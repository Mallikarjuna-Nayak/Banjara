const fs = require('fs');
module.exports = {
    getServiceContent  : function (jsonFileName) {
        const service_command = 
`[Unit]
    Description= eZintegrations pipeline
    After=multi-user.target
[Service]
    WorkingDirectory=/opt/pipeline/eZintegrations/bin
    Type=simple
    User=ubuntu
    Restart=always
    ExecStart=/usr/bin/python /opt/pipeline/eZintegrations/bin/__pipeline__.py --/opt/pipeline/eZintegrations/bin/${jsonFileName} --http_port 6267 --batch 5000 --worker 1 --logs /opt/pipeline/eZintegrations/logs/netsuite.log --wait_time 10
[Install]
    WantedBy=multi-user.target
`
        return service_command;
    },

    getJsonConfigContent : function (sourceData, targetData) {
        const rest_content = 
`{
    "bizdata_ops_restapi":{
        "min_num": 0 ,
        "max_num": 1000 ,
        "endpoint_url":"${sourceData.endpointUrl}",
        "endpoint_headers_raw":${sourceData.headers},
        "endpoint_method":"${sourceData.method}",
        "endpoint_body":${sourceData.body},
        "endpoint_params":${sourceData.params},
        "authentication_type":"${sourceData.authType}",
        "username":"${sourceData.userName}",
        "password":"${sourceData.password}",
        "refresh_token_url":"${sourceData.refreshTokenUrl}",
        "refresh_token_headers":${sourceData.refreshTokenHeaders},
        "refresh_token_method":"${sourceData.refreshTokenMethod}",
        "refresh_token_body":${sourceData.refreshTokenBody},
        "refresh_token_params":${sourceData.refreshTokenParams},
        "pre_request_script":"${sourceData.preRequestScript}",
        "response_parameters":"['items']",
        "another_response_parameter":"",
        "key_name_to_update":"offset",
        "user_key":"hasMore",
        "pagination_style":"offset_pagination",
        "timer_type":"schedule",
        "interval_in_seconds":10,
        "schedule":"*/5 * * * *",
        "target":"product_data",
        "user_key_url":"Link"
    },
    "bizdata_ops_singletomultiline":{
        "source":"product_data",
        "chop":"['items']",
        "target":"product_data"
    },
    "bizdata_output_restapi":{
        "source":"product_data",
        "endpoint_url":"${targetData.endpointUrl}",
        "endpoint_headers_raw":${targetData.headers},
        "endpoint_method":"${targetData.method}",
        "endpoint_body":${targetData.body},
        "endpoint_params":${targetData.params},
        "authentication_type":"${targetData.authType}",
        "username":"${targetData.userName}",
        "password":"${targetData.password}",
        "refresh_token_url":"${targetData.refreshTokenUrl}",
        "refresh_token_headers":${targetData.refreshTokenHeaders},
        "refresh_token_method":"${targetData.refreshTokenMethod}",
        "refresh_token_body":${targetData.refreshTokenBody},
        "refresh_token_params":${targetData.refreshTokenParams},
        "pre_request_script":"${targetData.preRequestScript}",
        "target":"bizdata_response"
    }
}
`
        return rest_content;
    },

    prepareServiceFile : function(objSourceParams, objTargetParams, jsonFileName, jsonfile, servicefile) {
        //Write Service File
        let data =  this.getServiceContent(jsonFileName);
        this.intBridgeFileWrite(data, servicefile);
        //Write Config File
        let objHeders = {};
        if(objSourceParams.input.bizdata_rest.endpoint_headers) {
            const arrHeaders = objSourceParams.input.bizdata_rest.endpoint_headers;
            arrHeaders.forEach(v => { objHeders[v["key"]] = v["value"] });
        }

        let objParams = {};
        if(objSourceParams.input.bizdata_rest.endpoint_params_raw) {
            const arrParams = objSourceParams.input.bizdata_rest.endpoint_params_raw;
            arrParams.forEach(v => { objParams[v["key"]] = v["value"] });
        }

        let authTypeId = objSourceParams.input.bizdata_rest.authentication_type.id;
        let authType = 'no_auth';
        let username = '';
        let password = '';
        let refresh_token_endpoint_url = '';
        let refresh_token_endpoint_header = '';
        let refresh_token_endpoint_method = '';
        let refresh_token_endpoint_body = '';
        let refresh_token_params = '';
        let preRequestScript = (objSourceParams.input.bizdata_rest.preRequestScript) ? objSourceParams.input.bizdata_rest.preRequestScript : '';

        if(authTypeId == 1) {
            authType = 'no_auth';
        }
        if(authTypeId == 4) {
            authType = 'basic_auth';
            username = objSourceParams.input.bizdata_rest.username;
            password = objSourceParams.input.bizdata_rest.password;
        }
        if(authTypeId == 6) {
            authType = 'oauth2.0';
            refresh_token_endpoint_url = objSourceParams.input.bizdata_rest.refresh_token_endpoint_url;
            refresh_token_endpoint_header = (objSourceParams.input.bizdata_rest.refresh_token_endpoint_header) ? objSourceParams.input.bizdata_rest.refresh_token_endpoint_header : '{}';
            refresh_token_endpoint_method = objSourceParams.input.bizdata_rest.refresh_token_endpoint_method.method;
            refresh_token_endpoint_body = objSourceParams.input.bizdata_rest.refresh_token_endpoint_body;
            refresh_token_params = (objSourceParams.input.bizdata_rest.refresh_token_endpoint_params) ? objSourceParams.input.bizdata_rest.refresh_token_endpoint_params : '{}';
        }
        
        const sourceData = {
            endpointUrl: objSourceParams.input.bizdata_rest.endpoint_url,
            headers: JSON.stringify(objHeders),
            method: objSourceParams.input.bizdata_rest.endpoint_method.method,
            body: JSON.stringify(objSourceParams.input.bizdata_rest.endpoint_body_raw),
            params: JSON.stringify(objParams),
            authType: authType,
            userName: username,
            password: password,
            refreshTokenUrl: refresh_token_endpoint_url,
            refreshTokenHeaders: refresh_token_endpoint_header,
            refreshTokenMethod: refresh_token_endpoint_method,
            refreshTokenBody: JSON.stringify(refresh_token_endpoint_body),
            refreshTokenParams: refresh_token_params,
            preRequestScript: preRequestScript,
        };

        let objHeders_Target = {};
        if(objTargetParams.input.bizdata_rest.endpoint_headers) {
            const arrHeaders = objTargetParams.input.bizdata_rest.endpoint_headers;
            arrHeaders.forEach(v => { objHeders_Target[v["key"]] = v["value"] });
        }

        let objParams_Target = {};
        if(objTargetParams.input.bizdata_rest.endpoint_params_raw) {
            const arrParams = objTargetParams.input.bizdata_rest.endpoint_params_raw;
            arrParams.forEach(v => { objParams_Target[v["key"]] = v["value"] });
        }

        let authTypeId_Target = objTargetParams.input.bizdata_rest.authentication_type.id;
        let authType_Target = 'no_auth';
        let username_Target = '';
        let password_Target = '';
        let refresh_token_endpoint_url_Target = '';
        let refresh_token_endpoint_header_Target = '';
        let refresh_token_endpoint_method_Target = '';
        let refresh_token_endpoint_body_Target = '';
        let refresh_token_params_Target = '';
        let preRequestScript_Target = objTargetParams.input.bizdata_rest.preRequestScript ? objTargetParams.input.bizdata_rest.preRequestScript : '';

        if(authTypeId_Target == 1) {
            authType_Target = 'no_auth';
        }
        if(authTypeId_Target == 4) {
            authType_Target = 'basic_auth';
            username_Target = objTargetParams.input.bizdata_rest.username;
            password_Target = objTargetParams.input.bizdata_rest.password;
        }
        if(authTypeId_Target == 6) {
            authType_Target = 'oauth2.0';
            refresh_token_endpoint_url_Target = objTargetParams.input.bizdata_rest.refresh_token_endpoint_url;
            refresh_token_endpoint_header_Target = (objTargetParams.input.bizdata_rest.refresh_token_endpoint_header) ? objTargetParams.input.bizdata_rest.refresh_token_endpoint_header : '{}';
            refresh_token_endpoint_method_Target = objTargetParams.input.bizdata_rest.refresh_token_endpoint_method.method;
            refresh_token_endpoint_body_Target = objTargetParams.input.bizdata_rest.refresh_token_endpoint_body;
            refresh_token_params_Target = (objTargetParams.input.bizdata_rest.refresh_token_endpoint_params) ? objTargetParams.input.bizdata_rest.refresh_token_endpoint_params : '{}';
        }

        const targetData = {
            endpointUrl: objTargetParams.input.bizdata_rest.endpoint_url,
            headers: JSON.stringify(objHeders_Target),
            method: objTargetParams.input.bizdata_rest.endpoint_method.method,
            body: JSON.stringify(objTargetParams.input.bizdata_rest.endpoint_body_raw),
            params: JSON.stringify(objParams_Target),
            authType: authType_Target,
            userName: username_Target,
            password: password_Target,
            refreshTokenUrl: refresh_token_endpoint_url_Target,
            refreshTokenHeaders: refresh_token_endpoint_header_Target,
            refreshTokenMethod: refresh_token_endpoint_method_Target,
            refreshTokenBody: JSON.stringify(refresh_token_endpoint_body_Target),
            refreshTokenParams: refresh_token_params_Target,
            preRequestScript: preRequestScript_Target,
        };

        let jsonData =  this.getJsonConfigContent(sourceData, targetData);
        this.intBridgeFileWrite(jsonData, jsonfile);

        return true;
    },

    intBridgeFileWrite :  function(inputData, path) {
        fs.open(path, 'w', 666, function( e, id ) {
            fs.write( id, inputData , null, 'utf-8', function(err, bytes){
                fs.close(id, function(){
                });
            });
        });
    }

}

const sql = require("./db.js");
const config = require("../config/config.js");
const { NotFoundError } = require("../helpers/utility");

// constructor
const TargetRepeat = function (targetRepeat) {
    if (typeof targetRepeat.id != 'undefined') {
        this.id = targetRepeat.id;
    }

    this.parent_id = targetRepeat.sourceId;
    this.key1 = targetRepeat.headerKey;
    this.value1 = targetRepeat.headerValue;
};

TargetRepeat.create = async (targetRepeat) => {
    let insert = await sql.query("INSERT INTO ic_tgt_restful_api_285_repeat SET ?", targetRepeat);
    if (insert.insertId) {
        return insert.insertId;
    }
    else {
        return;
    }
};

TargetRepeat.delete = async (parent_id) => {
    let row = await sql.query("DELETE FROM ic_tgt_restful_api_285_repeat WHERE parent_id = ?", [parent_id]);
    return row;
};

TargetRepeat.getSourceRepeat = async (value) => {
    let rows = await sql.query(`SELECT * FROM ic_tgt_restful_api_285_repeat WHERE parent_id = ?`, [value]);
    if (rows.length) {
        return rows;
    } else {
        return null;
    }
};

module.exports = TargetRepeat;

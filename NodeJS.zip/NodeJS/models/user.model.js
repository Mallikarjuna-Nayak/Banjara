const sql = require("./db.js");
const config = require("../config/config.js");
const { NotFoundError } = require("../helpers/utility");

// constructor
const User = function (user) {
  if (typeof user.id != "undefined") {
    this.id = user.id;
  }
  this.first_name = user.firstName;
  this.last_name = user.lastName;
  this.job_title = user.jobTitle;
  this.company = user.company;
  this.employee = user.employee;
  this.country = user.country;
  this.work_email = user.email;
  this.phone_no = user.phone;
  this.free_trial_mode = user.trail;
  // this.subscription_start_date = user.currentDateTime;
  // this.subscription_end_date = user.subscriptionEndDate;
  this.create_ip_address = user.create_ip_address;
  this.update_ip_address = user.create_ip_address;
  // this.password = user.password;
};

User.create = async (newUser) => {
  let query1 = "INSERT INTO yybiz_organization SET ?";
  let query2 = "INSERT INTO yybiz_users SET ?";
  let query3 = "SELECT * FROM yybiz_users WHERE email = ? AND delete_user = 0";
  if (newUser.free_trial_mode == 1) {
    delete newUser.subscription_start_date;
  }
  let org_insert = await sql.query(query1, newUser);
  let data = {
    first_name: newUser.first_name,
    last_name: newUser.last_name,
    email: newUser.work_email,
    organization_id: org_insert.insertId,
    create_ip_address: newUser.create_ip_address,
    update_ip_address: newUser.create_ip_address
  };
  await sql.query(query2, data);
  let row = await sql.query(query3, [newUser.work_email]);
  if (org_insert.insertId) {
    return row[0];
  } else {
    return;
  }
};

User.login = async (value) => {
  let row = await sql.query(
    `SELECT * FROM yybiz_users WHERE email = ? AND delete_user = 0 AND block=0`,
    [value]
  );

  if (row.length) {
    return row[0];
  } else {
    throw "User does not exist";
  }
};

User.orginationInfo = async (value) => {
  let row = await sql.query(
    `SELECT * FROM yybiz_organization WHERE work_email = ?`,
    [value]
  );
  if (row.length) {
    return row[0];
  } else {
    throw "User does not exist";
  }
};

User.getVerificationCode = async (value) => {
  let row = await sql.query(
    `SELECT verification_code FROM yybiz_users WHERE email = ? AND organization_id = ? AND activation = 0`,
    [value.email, value.id]
  );
  if (row.length) {
    return row[0];
  } else {
    throw "Code not found";
  }
};

User.setVerificationCode = async (value) => {
  let row = await sql.query(
    `UPDATE yybiz_users SET verification_code = ? WHERE email = ? AND organization_id = ?`,
    [value.vcode, value.email, value.id]
  );
  if (row.affectedRows) {
    let row = await sql.query(
      `SELECT * FROM yybiz_users WHERE email = ? AND organization_id = ?`,
      [value.email, value.id]
    );
    if (row.length) {
      return true;
    }
  } else {
    throw "Error while generating verification code";
  }
};

User.fetchQuestions = async () => {
  let questions = [];
  let row = await sql.query(
    `SELECT * FROM yybiz_security_questions WHERE status = 0`
  );
  // console.log(row);
  if (row.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(row)));
    for (var obj of arr) {
      obj.id = obj.ID;
      delete obj.ID;
      delete obj.created_date;
      delete obj.status;
      questions.push(obj);
    }
    return questions;
  } else {
    throw "Error while getting security questions";
  }
};

User.subscribe = async (value) => {
  let row = await sql.query(
    `SELECT subscription_start_date FROM yybiz_organization WHERE work_email = ? AND ID = ?`,
    [value.email, value.id]
  );
  if (row.length) {
    if (
      row[0].subscription_start_date == null ||
      row[0].subscription_start_date == ""
    ) {
      let subscription_number = Date.now();
      let row = await sql.query(
        `UPDATE yybiz_organization SET free_trial_mode = ?, subscription_start_date = ?, subscription_end_date = ?, subscription_number = ?  WHERE work_email = ? AND ID = ?`,
        [value.freeTrialMode, value.currentDateTime, value.subscriptionEndDate, subscription_number, value.email, value.id]
      );
      if (!row.affectedRows) {
        throw "Unable to subscribe";
      } else {
        let row = await sql.query(
          `SELECT * FROM yybiz_organization WHERE work_email = ? AND ID = ?`,
          [value.email, value.id]
        );
        return row[0];
      }
    } else {
      throw "Your are already a subscribe user";
    }
  } else {
    throw "Invalid input";
  }
};

User.setNewPassword = async (value) => {
  let row = await sql.query(
    `UPDATE yybiz_users SET security_question_id = ?, security_question_answer = ?, password = ? WHERE email = ? AND organization_id = ?`,
    [value.questId, value.answer, value.password, value.email, value.id]
  );
  if (!row.affectedRows) {
    throw "Unable to set password";
  }
};

User.getUser = async (value) => {
  let row = await sql.query(
    `SELECT * FROM yybiz_users WHERE email = ? AND delete_user = 0`,
    [value]
  );
  if (row.length) {
    return row[0];
  } else {
    return null;
  }
};

User.changePassword = async (id, password) => {
  let row = await sql.query(
    `UPDATE yybiz_users SET password = ? WHERE id = ?`,
    [password, id]
  );
  if (!row.affectedRows) {
    throw "Error while updating the password";
  }
};

User.validateUser = async (email, id) => {
  let row = await sql.query(
    `SELECT * FROM yybiz_users WHERE email = ? and ID = ? and delete_user = 0`,
    [email, id]
  );
  if (row.length) {
    return row[0];
  } else {
    return false;
  }
};

User.getUserProfileImage = async (id) => {
  let row = await sql.query(`SELECT image FROM yybiz_images_collection WHERE id = ?`, [id]);
  if (row.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(row)));
    return { "profileImage_hash": arr[0].image };
  } else {
    throw "Profile image does not exists";
  }
};

User.saveProfileImage = async (user_id, bufferBase64) => {
  //Insert profile image
  let row = await sql.query(`insert into yybiz_images_collection SET image = ?`, [bufferBase64]);
  if (row.insertId) {
    //update yybiz_users
    let rows = await sql.query(`UPDATE yybiz_users SET profile_image = ? WHERE id = ?`, [row.insertId, user_id]);
    if (rows.affectedRows) {
      return true;
    } else {
      throw "Unable to save profile image";
    }
  } else {
    throw "Error in saving profile image";
  }
};

User.updateProfileImage = async (img_collection_id, bufferBase64) => {
  //Update existing profile image
  let rows = await sql.query(`UPDATE yybiz_images_collection SET image = ? WHERE id = ?`, [bufferBase64, img_collection_id]);
  if (rows.affectedRows) {
    return true;
  } else {
    throw "Unable to update profile image";
  }
};

User.deleteUserProfileImage = async (userId, collectionId) => {
  let rows = await sql.query(`UPDATE yybiz_users SET profile_image = '' WHERE id = ?`, [userId]);
  if (rows.affectedRows) {
    let row = await sql.query(`DELETE FROM yybiz_images_collection WHERE id = ?`, [collectionId]);
    if (row.affectedRows) {
      return true;
    } else {
      throw "Unable to delete profile image";
    }
  } else {
    throw "Error in deleting profile image";
  }
};

User.deleteUser = async (id) => {
  let row = await sql.query(`UPDATE yybiz_users SET delete_user = ? WHERE ID = ?`, [1, id]);
  if (row.affectedRows) {
    return true;
  } else {
    throw "Unable to delete";
  }
};

User.getAllUsersCount = async () => {
  let rows = await sql.query(
    `SELECT count(id) as userCount FROM yybiz_users WHERE delete_user = 0`);

  if (rows.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(rows)));
    return arr[0].userCount;
  } else {
    throw "Error in getting count";
  }
};

User.getAllUsers = async (min, max, cnt, sort, order, q) => {
  let usersList = [];
  var default_sort = 'u1.updated_date';
  var default_order = 'DESC';
  var rows = '';
  let query = `SELECT u1.*, u2.first_name as fname_updatedby, u2.last_name as lname_updatedby, u3.first_name as fname_createdby, u3.last_name as lname_createdby FROM yybiz_users as u1 LEFT JOIN yybiz_users as u2 on u1.updated_by = u2.ID LEFT JOIN yybiz_users as u3 on u1.created_by = u3.ID WHERE u1.delete_user = 0 `;
  if (q != "") {
    query += ' and (u1.first_name like "%' + q + '%" or u1.last_name like "%' + q + '%" or u1.email like "%' + q + '%" or u2.first_name like "%' + q + '%" or u2.last_name like "%' + q + '%" or u3.first_name like "%' + q + '%" or u3.last_name like "%' + q + '%") ';
  }
  var parameters = (sort ? sort : default_sort) + ' ' + (order ? order : default_order);
  var sqlQ = query + ' ORDER BY ' + parameters;

  if (min !== "" && max !== "") {
    let sqlquery = sqlQ + ' LIMIT ' + min + ' , ' + max;
    rows = await sql.query(sqlquery);
  } else {
    rows = await sql.query(sqlQ);
  }
  if (rows.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(rows)));
    arr.forEach(function (item) {
      let data = {
        id: item.ID,
        updated_by: item.fname_updatedby ? item.fname_updatedby + ' ' + item.lname_updatedby : '',
        created_by: item.created_by ? item.fname_createdby + ' ' + item.lname_createdby : item.first_name + ' ' + item.last_name,
        created_date: item.created_date,
        updated_date: item.updated_date,
        create_ip_address: item.create_ip_address ? item.create_ip_address : '',
        update_ip_address: item.update_ip_address ? item.update_ip_address : '',
        organization_id: item.organization_id,
        first_name: item.first_name,
        last_name: item.last_name,
        email: item.email,
        block: item.block ? true : false
      }
      usersList.push(data);
    });
    if (q != '') { cnt = rows.length; }
    let usersData = { "total_count": cnt, "records": usersList };
    return usersData;
  } else {
    let usersData = { "total_count": 0, "records": [] };
    return usersData;
  }
};

/*  Purpose: Add or create a new user data
*   Author: Mallikarjuna Nayak
*	Date: 16-02-2022
*/
User.createNewUserApi = async (values, hasPassword) => {
  let row = await sql.query(`SELECT * FROM yybiz_users WHERE email = ?`, [values.email]);
  if (row.length) {
    throw "User Email is already existed. Please enter new email";
  } else {
    let userSqlQuery = "INSERT INTO yybiz_users SET ?";
    let userGrpSql = `INSERT INTO yybiz_user_usergroup_map SET ?`; // user_id, user_group_id
    let userData = {
      created_by: values.created_by,
      create_ip_address: values.create_ip_address,
      first_name: values.first_name,
      last_name: values.last_name,
      email: values.email,
      password: hasPassword,
    };
    let rows = await sql.query(userSqlQuery, userData);
    if (rows.affectedRows) {
      if (typeof values.userGroups !== 'undefined' && values.userGroups.length > 0) {
        const grpArray = values.userGroups;
        grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
          var post = {
            user_id: rows.insertId,
            user_group_id: element,
          };
          let user_grp_row = await sql.query(userGrpSql, post);//ALTER TABLE `yybiz_user_usergroup_map` CHANGE `ID` `ID` INT(11) NOT NULL AUTO_INCREMENT, add PRIMARY KEY (`ID`);
        });
      }
      return true;
    } else {
      throw "Error while creating the user";
    }
  }
};

User.getUserSelectedGroups = async (ID) => {
  let userGroups = [];
  let rows = await sql.query(`SELECT ug.user_group_id FROM yybiz_user_usergroup_map as ug WHERE ug.user_id = ?`, [ID]);
  if (rows.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(rows)));
    arr.forEach(function (item) {
      // let data = {
      // 	user_group_id: item.user_group_id
      // }
      userGroups.push(item.user_group_id);
    });
  }
  return userGroups;
};


/*  Purpose: Get user data by id to edit
*   Author: Mallikarjuna Nayak
*	Date: 11-02-2022
*/
User.userApiEdit = async (ID, user_selected_grp) => {
  let organization = [];
  let rows = await sql.query(`SELECT u1.*, u2.first_name as fname_updatedby, u2.last_name as lname_updatedby, u3.first_name as fname_createdby, u3.last_name as lname_createdby
                              FROM yybiz_users as u1
                              LEFT JOIN yybiz_users as u2 on u1.updated_by = u2.ID
                              LEFT JOIN yybiz_users as u3 on u1.created_by = u3.ID
                              WHERE u1.delete_user = 0 AND u1.ID = ?`, [ID]);
  if (rows.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(rows)));
    arr.forEach(function (item) {
      let data = {
        id: item.ID,
        updated_by: item.fname_updatedby ? item.fname_updatedby + ' ' + item.lname_updatedby : '',
        created_by: item.created_by ? item.fname_createdby + ' ' + item.lname_createdby : item.first_name + ' ' + item.last_name,
        created_date: item.created_date,
        updated_date: item.updated_date,
        create_ip_address: item.create_ip_address ? item.create_ip_address : '',
        update_ip_address: item.update_ip_address ? item.update_ip_address : '',
        organization_id: item.organization_id,
        first_name: item.first_name,
        last_name: item.last_name,
        email: item.email,
        block: (item.block == 1) ? true : false,
        user_selected_grp: (user_selected_grp.length) ? user_selected_grp : ''
      }
      organization.push(data);
    });
    return organization;
  } else {
    throw "Error while fetching organization data";
  }
};

User.updateApiUser = async (values, hasPassword) => {
  var block = 0;
  if (values.block == true) {
    block = 1;
  }
  let org_row = await sql.query(`SELECT organization_id FROM yybiz_users WHERE organization_id IS NOT NULL AND ID = ? `, [values.ID]);
  let updateUsers = `UPDATE yybiz_users SET first_name = ?, last_name = ?, updated_by = ?, update_ip_address = ?, block = ? WHERE ID = ?`;
  if (hasPassword) {
    updateUsers = `UPDATE yybiz_users SET first_name = ?, last_name = ?, updated_by = ?, update_ip_address = ?, block = ?, password = ? WHERE ID = ?`;
  }

  let updateOrg = `UPDATE yybiz_organization SET first_name = ?, last_name = ?, updated_by = ?, update_ip_address = ? WHERE ID = ?`;
  /****** Logic for userGroup starts here ******/
  let userGrpSql = `INSERT INTO yybiz_user_usergroup_map SET ?`;
  if (typeof values.userGroups !== 'undefined' && values.userGroups.length > 0) {
    let user_has_group = await sql.query(`SELECT ID, user_id, user_group_id FROM yybiz_user_usergroup_map WHERE user_id = ? `, [values.ID]);
    if (user_has_group.length) {
      let user_group_del = await sql.query(`DELETE FROM yybiz_user_usergroup_map WHERE user_id = ?`, values.ID);
      const grpArray = values.userGroups;
      grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
        var post = {
          user_id: values.ID,
          user_group_id: element,
        };
        let user_grp_row = await sql.query(userGrpSql, post);
      });

    } else {
      const grpArray = values.userGroups;
      grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
        var post = {
          user_id: values.ID,
          user_group_id: element,
        };
        let user_grp_row = await sql.query(userGrpSql, post);
      });
    }
  }
  /******* Logic for userGroup ends here *******/

  if (org_row.length) {
    let ORGID = JSON.stringify(org_row[0].organization_id);
    if (hasPassword) {
      var row = await sql.query(updateUsers, [values.first_name, values.last_name, values.updated_by, values.update_ip_address, block, hasPassword, values.ID]);
    } else {
      var row = await sql.query(updateUsers, [values.first_name, values.last_name, values.updated_by, values.update_ip_address, block, values.ID]);
    }

    var rows = await sql.query(updateOrg, [values.first_name, values.last_name, values.updated_by, values.update_ip_address, ORGID]);
    if (row.affectedRows && rows.affectedRows) {
      return true;
    } else {
      throw "Something went wrong while updating the user or organization data";
    }
  } else {
    if (hasPassword) {
      var row = await sql.query(updateUsers, [values.first_name, values.last_name, values.updated_by, values.update_ip_address, block, hasPassword, values.ID]);
    } else {
      var row = await sql.query(updateUsers, [values.first_name, values.last_name, values.updated_by, values.update_ip_address, block, values.ID]);
    }

    if (row.affectedRows) {
      return true;
    } else {
      throw "Something went wrong while updating the user data";
    }
  }
};


/*  Purpose: Get all User_group data in the request
*   Author: Mallikarjuna Nayak
*	Date: 14-02-2022
*/
User.getAllUserGroups = async (min, max, cnt, sort, order, q) => {
  let AllUser_group = [];
  var default_sort = 'u1.last_updated_date';
  var default_order = 'DESC';
  var rows = '';
  var query = `SELECT u1.*, u2.first_name as fname_updatedby, u2.last_name as lname_updatedby, u3.first_name as fname_createdby, u3.last_name as lname_createdby FROM yybiz_usergroups as u1 LEFT JOIN yybiz_users as u2 on u1.updated_by = u2.ID LEFT JOIN yybiz_users as u3 on u1.created_by = u3.ID WHERE u1.is_deleted = 0 `;

  if (q != "") {
    query += ' and (u1.title like "%' + q + '%" or u2.first_name like "%' + q + '%" or u2.last_name like "%' + q + '%" or u3.first_name like "%' + q + '%" or u3.last_name like "%' + q + '%") ';
  }

  var parameters = (sort ? sort : default_sort) + ' ' + (order ? order : default_order);
  var sqlQ = query + ' ORDER BY ' + parameters;

  if (min !== "" && max !== "") {
    let sqlquery = sqlQ + ' LIMIT ' + min + ' , ' + max;
    rows = await sql.query(sqlquery);
  } else {
    rows = await sql.query(sqlQ);
  }

  if (rows.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(rows)));
    arr.forEach(function (item) {
      let data = {
        id: item.ID,
        updated_by: item.fname_updatedby ? item.fname_updatedby + ' ' + item.lname_updatedby : '',
        created_by: item.created_by ? item.fname_createdby + ' ' + item.lname_createdby : item.first_name + ' ' + item.last_name,
        created_date: item.created_date,
        last_updated_date: item.last_updated_date,
        create_ip_address: item.create_ip_address ? item.create_ip_address : '',
        update_ip_addres: item.update_ip_addres ? item.update_ip_addres : '',
        parent_id: item.parent_id,
        title: item.title,
        view_id: item.view_id,
        group_access: item.group_access,
        is_deleted: (item.is_deleted == 1) ? true : false,
      }
      AllUser_group.push(data);
    });
    if (q != '') { cnt = rows.length; }
    AllUser_groupData = { "total_count": cnt, "records": AllUser_group };
    return AllUser_groupData;
  } else {
    let AllUser_groupData = { "total_count": 0, "records": [] };
    return AllUser_groupData;
  }
};
User.getTotalUserGroups = async () => {
  let query = `SELECT count(ID) as userGroupCount FROM yybiz_usergroups where is_deleted = 0`;
  let rows = await sql.query(query);
  if (rows.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(rows)));
    return arr[0].userGroupCount;
  } else {
    throw "Error in getting count";
  }
}

/*  Purpose: Add new user_group data
*   Author: Mallikarjuna Nayak
*	Date: 14-02-2022
*/
User.addUserGroups = async (values) => {

  let sqlQuery = `INSERT INTO yybiz_usergroups SET ?`;
  let userGrpSql = `INSERT INTO yybiz_usergroups_repeat_group_access SET ?`;
  let data = {
    created_by: values.created_by,
    create_ip_address: values.create_ip_address,
    parent_id: values.parent_id,
    title: values.title,
    view_id: values.view_id,
    group_access: values.group_access,
  };
  let row = await sql.query(sqlQuery, data);
  if (row.affectedRows) {
    if (typeof values.userGroups !== 'undefined' && values.userGroups.length > 0) {
      const grpArray = values.userGroups;
      grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
        var post = {
          parent_id: row.insertId,
          group_access: element,
        };
        let user_grp_row = await sql.query(userGrpSql, post);
      });
    }
    return true;
  } else {
    throw "Error while Inserting the Record";
  }
};

/*  Purpose: Get user_associated_group data by id to edit
*   Author: Mallikarjuna Nayak
*	Date: 23-02-2022
*/
User.getUserAssocGroups = async (ID) => {
  let userGroups = [];
  let rows = await sql.query(`SELECT ug.group_access AS userGroups FROM yybiz_usergroups_repeat_group_access as ug WHERE ug.parent_id = ?`, [ID]);
  if (rows.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(rows)));
    arr.forEach(function (item) {
      // let data = {
      // 	user_group_id: item.user_group_id
      // }
      userGroups.push(item.userGroups);
    });
  }
  return userGroups;
};

/*  Purpose: Get user_group data by id to edit
*   Author: Mallikarjuna Nayak
*	Date: 14-02-2022
*/
User.editUserGroups = async (ID, userGroups) => {
  let User_groupApi = [];
  let rows = await sql.query(`SELECT u1.*, u2.first_name as fname_updatedby, u2.last_name as lname_updatedby, u3.first_name as fname_createdby, u3.last_name as lname_createdby FROM yybiz_usergroups as u1 LEFT JOIN yybiz_users as u2 on u1.updated_by = u2.ID LEFT JOIN yybiz_users as u3 on u1.created_by = u3.ID WHERE u1.is_deleted = 0 AND u1.ID = ?`, ID);
  if (rows.length) {
    let arr = Object.values(JSON.parse(JSON.stringify(rows)));
    arr.forEach(function (item) {
      let data = {
        id: item.ID,
        updated_by: item.fname_updatedby ? item.fname_updatedby + ' ' + item.lname_updatedby : '',
        created_by: item.created_by ? item.fname_createdby + ' ' + item.lname_createdby : item.first_name + ' ' + item.last_name,
        created_date: item.created_date,
        last_updated_date: item.last_updated_date,
        create_ip_address: item.create_ip_address,
        update_ip_addres: item.update_ip_addres,
        parent_id: item.parent_id,
        title: item.title,
        view_id: item.view_id,
        group_access: item.group_access,
        is_deleted: item.is_deleted ? true : false,
        userGroups: (userGroups.length) ? userGroups : ''
      }
      User_groupApi.push(data);
    });
    return User_groupApi;
  } else {
    throw "Error while fetching User_group data";
  }
};

/*  Purpose: Update user_group data by id to modify
*   Author: Mallikarjuna Nayak
*	Date: 14-02-2022
*/
User.updateUserGroups = async (values) => {
  let sqlQuery = `UPDATE yybiz_usergroups SET updated_by = ?, update_ip_addres = ?, parent_id = ?, title = ?, view_id = ?, group_access = ?, is_deleted = ? WHERE ID = ?`;
  let data = [
    values.updated_by,
    values.update_ip_addres,
    values.parent_id,
    values.title,
    values.view_id,
    values.group_access,
    values.is_deleted,
    values.ID
  ];
  let row = await sql.query(sqlQuery, data);

  /****** Logic for userGroup starts here ******/
  let userGrpSql = `INSERT INTO yybiz_usergroups_repeat_group_access SET ?`;
  if (typeof values.userGroups !== 'undefined' && values.userGroups.length > 0) {
    let user_has_group = await sql.query(`SELECT ID, parent_id, group_access FROM yybiz_usergroups_repeat_group_access WHERE parent_id = ? `, [values.ID]);
    if (user_has_group.length) {
      let user_group_del = await sql.query(`DELETE FROM yybiz_usergroups_repeat_group_access WHERE parent_id = ?`, values.ID);
      const grpArray = values.userGroups;
      grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
        var post = {
          parent_id: values.ID,
          group_access: element,
        };
        let user_grp_row = await sql.query(userGrpSql, post);
      });

    } else {
      const grpArray = values.userGroups;
      grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
        var post = {
          parent_id: values.ID,
          group_access: element,
        };
        let user_grp_row = await sql.query(userGrpSql, post);
      });
    }
  } else {
    let user_group_del = await sql.query(`DELETE FROM yybiz_usergroups_repeat_group_access WHERE parent_id = ?`, values.ID);
  }
  /******* Logic for userGroup ends here *******/

  if (row.affectedRows) {
    return true;
  } else {
    throw "Error while updating the Record";
  }
};

/*  Purpose: Delete user_group data by id
*   Author: Mallikarjuna Nayak
*	Date: 14-02-2022
*/
User.deleteUserGroups = async (ID) => {
  let row = await sql.query(`UPDATE yybiz_usergroups SET is_deleted = ? WHERE ID = ?`, [1, ID]);
  if (row.affectedRows) {
    return true;
  } else {
    throw "Not existed";
  }
};

/**
 * Purpose: Profile Change password request
 * Author: Mallikarjuna Nayak
 * Date: 29-03-2022
 */
User.changeUserPassword = async (new_hasPassword, id) => {
  let row = await sql.query(`UPDATE yybiz_users SET password = ? WHERE ID = ?`, [new_hasPassword, id]);
  if (row.affectedRows) {
    return true;
  }
};

User.getUserPassword = async (id) => {
  let row = await sql.query(`SELECT first_name, last_name, email, password FROM yybiz_users WHERE ID = ? AND delete_user = 0`, [id]);
  if (row.length) {
    return row[0];
  } else {
    throw "User does not exist";
  }
};


module.exports = User;

const sql = require("./db.js");

const Organization = {
    getOrganizationCount: async () => {
        let rows = await sql.query(
            `SELECT count(ID) as userCount FROM yybiz_organization WHERE is_deleted = 0`);

        if (rows.length) {
        let arr = Object.values(JSON.parse(JSON.stringify(rows)));
        return arr[0].userCount;
        } else {
            throw "Error in getting count";
        }
    },

    getOrganization: async (min, max, cnt, sort, order, q) => {
        let organization = [];
		var default_sort = 'updated_date';
		var default_order = 'DESC';
		var rows = '';
		var query = 'SELECT o.*, u.first_name as updated_fname, u.last_name as updated_lname FROM yybiz_organization as o left join yybiz_users as u on u.ID = o.updated_by where o.is_deleted = 0 ';

        if(q != "") {
            query += ' and (o.first_name like "%'+q+'%" or o.last_name like "%'+q+'%" or o.work_email like "%'+q+'%" or o.company like "%'+q+'%" or o.job_title like "%'+q+'%" or o.country like "%'+q+'%") ';
        }

        var parameters = (sort ? sort : default_sort)+' '+(order ? order : default_order);
        var sqlQ = query+' ORDER BY '+parameters;

		 if(min !== "" && max !== "") {
			let sqlquery = sqlQ+' LIMIT '+min+' , '+max;
			rows = await sql.query(sqlquery);
		} else {
			rows = await sql.query(sqlQ);
        }

		if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    first_name: item.first_name,
                    last_name: item.last_name,
                    email: item.work_email,
                    phone_no: item.phone_no,
                    job_title: item.job_title,
                    employee: item.employee,
                    company: item.company,
                    country: item.country,
                    biz_client_id:item.biz_client_id ? item.biz_client_id : "",
                    biz_client_secret:item.biz_client_secret ? item.biz_client_secret : "",
                    free_trial_mode:item.free_trial_mode,
                    subscription_start_date:item.subscription_start_date,
                    subscription_end_date:item.subscription_end_date,
                    subscription_number:item.subscription_number,
                    statement:item.statement,
                    company_logo: (item.company_logo) ? item.company_logo: "",
                    company_address:item.company_address,
                    updated_by:(item.updated_fname) ? item.updated_fname+' '+item.updated_lname : "",
                    created_date:item.created_date,
                    updated_date:item.updated_date,
                    create_ip_address:item.create_ip_address,
                    update_ip_address:item.update_ip_address
                }
                organization.push(data);
            });
            if(q != '') { cnt = rows.length;}
            let organizationData = {"total_count": cnt, "records": organization };
            return organizationData;
        } else {
            let organizationData = {"total_count": 0, "records": [] };
            return organizationData;
        }
    },

    editApiOrganization: async (ID) => {
        let organization = [];
        let rows = await sql.query(`SELECT o.*, u.first_name as updated_fname, u.last_name as updated_lname FROM yybiz_organization as o 
        left join yybiz_users as u on u.ID = o.updated_by
        WHERE o.is_deleted = 0 and o.ID = ?`, ID);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    first_name: item.first_name,
                    last_name: item.last_name,
                    email: item.work_email,
                    phone_no: item.phone_no,
                    job_title: item.job_title,
                    employee: item.employee,
                    company: item.company,
                    country: item.country,
                    biz_client_id:item.biz_client_id,
                    biz_client_secret:item.biz_client_secret ? item.biz_client_secret : "",
                    free_trial_mode:item.free_trial_mode,
                    subscription_start_date:item.subscription_start_date,
                    subscription_end_date:item.subscription_end_date,
                    subscription_number:item.subscription_number,
                    statement:item.statement,
                    company_logo:item.company_logo,
                    company_address:item.company_address,
                    updated_by: (item.updated_fname) ? item.updated_fname+' '+item.updated_lname : "",
                    created_date:item.created_date,
                    updated_date:item.updated_date,
                    create_ip_address:item.create_ip_address,
                    update_ip_address:item.update_ip_address
                }
                organization.push(data);
            });
            return organization;
        } else {
            throw "Error while fetching organization data";
        }
    },

	updateApiOrganization: async (values) => {
		let sqlQuery = `UPDATE yybiz_organization SET first_name = ?, last_name = ?, work_email = ?, phone_no = ?, job_title = ?, employee = ?, company = ?, country = ?, company_logo = ?, company_address = ?, updated_by = ?, update_ip_address = ?, subscription_end_date = ? WHERE ID = ?`;
		let data = [
			values.first_name,
			values.last_name,
			values.email,
			values.phone_no,
            values.job_title,
            values.employee,
            values.company,
            values.country,
            values.company_logo,
            values.company_address,
            values.updated_by,
            values.update_ip_address,
            values.subscription_end_date,
			values.ID
		];

		let row = await sql.query(sqlQuery, data);
		if (!row.affectedRows) {
			throw "Error while updating the Record";
		}
        let updateUsers = `UPDATE yybiz_users SET first_name = ?, last_name = ?, email = ?, updated_by = ?, update_ip_address = ?  WHERE organization_id = ?`;
        let UserData = [
		    values.first_name,
		    values.last_name,
		    values.email,
            values.updated_by,
            values.update_ip_address,
		    values.ID
	    ];
        let rows = await sql.query(updateUsers, UserData);
		if (rows.affectedRows) {
			return true;
		} else {
            throw "Error while updating the Record";
        }
	},

	removeApiOrganization: async (ID) => {
		let rows = await sql.query(`UPDATE yybiz_organization SET is_deleted = 1 WHERE ID = ?`, [ID]);
		if (rows.affectedRows) {
			return true;
		} else {
			throw "Not existed";
		}
	},

    getLogoImage: async (id) => {
        let row = await sql.query(`SELECT image FROM yybiz_images_collection WHERE id = ?`, [id]);
        if (row.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(row)));
            return {"logo_hash": arr[0].image};
        } else {
            throw "No logo exists";
        }
    },

    saveCompanyLogo: async (organization_id, bufferBase64) => {
        //Insert logo
        let row = await sql.query(`insert into yybiz_images_collection SET image = ?`, [bufferBase64]);
        if (row.insertId) {
            //update yybiz_organization
            let rows = await sql.query(`UPDATE yybiz_organization SET company_logo = ? WHERE id = ?`, [row.insertId, organization_id]);
            if (rows.affectedRows) {
                return true;
            } else {
                throw "Error in updating data";
            }
        } else {
            throw "Error in saving logo";
        }
    },

    updateCompanyLogo: async (img_collection_id, bufferBase64) => {
        //Update existing logo
        let rows = await sql.query(`UPDATE yybiz_images_collection SET image = ? WHERE id = ?`, [bufferBase64, img_collection_id]);
        if (rows.affectedRows) {
            return true;
        } else {
            throw "Unable to update logo image";
        }
    },

    deleteLogoImage: async (orgId, collectionId) => {
		let rows = await sql.query(`UPDATE yybiz_organization SET company_logo = '' WHERE ID = ?`, [orgId]);
		if (rows.affectedRows) {
            let row = await sql.query(`DELETE FROM yybiz_images_collection WHERE id = ?`, [collectionId]);
            if (row.affectedRows) {
                return true;
            } else {
                throw "Unable to delete logo";
            }
		} else {
			throw "Error in deleting logo";
		}
	},

    getProfileInfo: async (ID) => {
        let organization = [];
        let rows = await sql.query(`SELECT o.*, u.profile_image as profile_image_id FROM yybiz_organization as o 
        left join yybiz_users as u on u.organization_id = o.ID
        WHERE o.is_deleted = 0 and o.ID = ?`, ID);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    first_name: item.first_name,
                    last_name: item.last_name,
                    email: item.work_email,
                    phone_no: item.phone_no,
                    job_title: item.job_title,
                    employee: item.employee,
                    company: item.company,
                    country: item.country,
                    statement:item.statement,
                    company_logo:item.company_logo,
                    company_address:item.company_address,
                    profile_image_id:item.profile_image_id
                }
                organization.push(data);
            });
            return organization;
        } else {
            throw "Error while fetching profile";
        }
    },

    updateProfileInfo: async (values) => {
		let sqlQuery = `UPDATE yybiz_organization SET first_name = ?, last_name = ?, phone_no = ?, job_title = ?, employee = ?, company = ?, country = ?, company_address = ?, updated_by = ?, update_ip_address = ? WHERE ID = ?`;
		let data = [
			values.first_name,
			values.last_name,
			values.phone_no,
            values.job_title,
            values.employee,
            values.company,
            values.country,
            values.company_address,
            values.updated_by,
            values.update_ip_address,
			values.ID
		];

		let row = await sql.query(sqlQuery, data);
		if (!row.affectedRows) {
			throw "Error while updating the Record";
		}
        let updateUsers = `UPDATE yybiz_users SET first_name = ?, last_name = ?, updated_by = ?, update_ip_address = ? WHERE organization_id = ?`;
        let UserData = [
		    values.first_name,
		    values.last_name,
            values.updated_by,
            values.update_ip_address,
		    values.ID
	    ];
        let rows = await sql.query(updateUsers, UserData);
		if (rows.affectedRows) {
			return true;
		} else {
            throw "Error while updating the Record";
        }
	},

}

module.exports = Organization;
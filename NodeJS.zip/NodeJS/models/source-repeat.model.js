const sql = require("./db.js");
const config = require("../config/config.js");
const { NotFoundError } = require("../helpers/utility");

// constructor
const SourceRepeat = function (sourceRepeat) {
    if (typeof sourceRepeat.id != 'undefined') {
        this.id = sourceRepeat.id;
    }

    this.parent_id = sourceRepeat.sourceId;
    this.Key = sourceRepeat.headerKey;
    this.Value = sourceRepeat.headerValue;
};

SourceRepeat.create = async (sourceRepeat) => {
    let insert = await sql.query("INSERT INTO ic_source_adv_rest_452_repeat SET ?", sourceRepeat);
    if (insert.insertId) {
        return insert.insertId;
    }
    else {
        return;
    }
};

SourceRepeat.delete = async (parent_id) => {
    let row = await sql.query("DELETE FROM ic_source_adv_rest_452_repeat WHERE parent_id = ?", [parent_id]);
    return row;
};

SourceRepeat.getSourceRepeat = async (value) => {
    let rows = await sql.query(`SELECT * FROM ic_source_adv_rest_452_repeat WHERE parent_id = ?`, [value]);
    if (rows.length) {
        return rows;
    } else {
        return null;
    }
};

module.exports = SourceRepeat;

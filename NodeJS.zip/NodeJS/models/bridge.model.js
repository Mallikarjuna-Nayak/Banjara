// const sql = require("./db.js");
// const config = require("../config/config.js");
// const { NotFoundError } = require("../helpers/utility");

// // constructor
// const Bridge = function (bridge, userId) {
//     if (typeof bridge.bridgeId != 'undefined') {
//         this.id = bridge.bridgeId;
//     }

//     this.integration_name = ;

//     this.source_type = ;
//     this.target_type = bridge.dataMethod.id;
//     this.target_id = bridge.body;

//     this.message = ;
//     this.status = ;




//     this.conf_file
//     this.input_auto
//     this.output_auto
//     this.source_id
//     this.updated_by
//     this.created_by
//     this.last_updated_date
//     this.created_date



//     this.target_object_name
//     this.mapping_structure
//     this.select_type
//     this.access_level
//     this.integration_number
//     this.primary_key_column
//     this.querystringvalue
//     this.workers
//     this.batch_size
//     this.java_opts_size
//     this.containers
//     this.customer_id
//     this.group_id
//     this.node_id
//     this.select_group
//     this.created_by_id
//     this.group_for_analytics
//     this.integration_audit_required
//     this.ingestion_type


// };

// Bridge.create = async (bridge) => {
//     let insert = await sql.query("INSERT INTO ic_bridge_adv_rest SET ?", bridge);
//     if (insert.insertId) {
//         return insert.insertId;
//     }
//     else {
//         return;
//     }
// };

// Bridge.update = async (bridge) => {
//     let sqlQuery = `UPDATE ic_integration_bridge
//            SET bridge_name = ?,
//            endpoint_url = ?,
//            method = ?,
//            body = ?,
//            authentication_type = ?,
//            refresh_token_endpoint_url = ?,
//            refresh_token_endpoint_header = ?,
//            refresh_token_endpoint_body = ?,
//            refresh_token_endpoint_method = ?,
//            username = ?,
//            password = ?,
//            customer_id = ?,
//            pagination_type = ?,
//            cursor_key = ?,
//            user_key = ?,
//            user_key_url = ?,
//            pagination_param_for_body_update = ?
//            WHERE id = ?`;

//     let data = [
//         bridge.bridge_name,
//         bridge.endpoint_url,
//         bridge.method,
//         bridge.body,
//         bridge.authentication_type,
//         bridge.refresh_token_endpoint_url,
//         bridge.refresh_token_endpoint_header,
//         bridge.refresh_token_endpoint_body,
//         bridge.refresh_token_endpoint_method,
//         bridge.username,
//         bridge.password,
//         bridge.customer_id,
//         bridge.pagination_type,
//         bridge.cursor_key,
//         bridge.user_key,
//         bridge.user_key_url,
//         bridge.pagination_param_for_body_update,
//         bridge.id
//     ];

//     let row = await sql.query(sqlQuery, data);
//     if (!row.affectedRows) {
//         throw "Error while updating the bridge";
//     }
//     return row;
// };

// Bridge.getBridges = async (value) => {
//     let rows = await sql.query(`SELECT bridge_name, id FROM ic_integration_bridge WHERE customer_id = ?`, [value]);
//     if (rows.length) {
//         return rows;
//     } else {
//         return [];
//     }
// };

// Bridge.getBridgesAndBridgesRepeat = async (value) => {
//     let rows = await sql.query(`SELECT t1.*, t2.Key, t2.Value FROM ic_integration_bridge t1 INNER JOIN ic_bridge_adv_rest_452_repeat t2 ON t2.parent_id = t1.id WHERE t1.id = ?`, [value]);
//     if (rows.length) {
//         return rows;
//     } else {
//         return null;
//     }
// };
// module.exports = Bridge;

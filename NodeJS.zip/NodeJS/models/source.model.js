const sql = require("./db.js");
const config = require("../config/config.js");
const { NotFoundError } = require("../helpers/utility");

// constructor
const Source = function (source, userId) {
    if (typeof source.sourceId != 'undefined') {
        this.id = source.sourceId;
    }

    // source info
    this.source_name = source.dataSource.name ? source.dataSource.name : source.dataSource;

    // http properties
    this.endpoint_url = source.dataUrl;
    this.method = source.dataMethod.id;
    this.body = source.body;

    // authentication
    this.authentication_type = source.authenticationtype.id;
    this.refresh_token_endpoint_url = source.authenticationsettings[0].oauth_refresh_token_endpoint_url || null;
    this.refresh_token_endpoint_header = source.authenticationsettings[0].oauth_refresh_token_endpoint_header || null;
    this.refresh_token_endpoint_body = source.authenticationsettings[0].oauth_refresh_token_endpoint_body || null;
    this.refresh_token_endpoint_method = source.authenticationsettings[0].oauth_refresh_token_endpoint_method || null;
    this.username = source.authenticationsettings[0].auth_Username || null;
    this.password = source.authenticationsettings[0].auth_password || null;

    // user details
    this.customer_id = userId;

    // timelinesetings
    this.rolling_frequency = source.timeelementsettings[0].pagination_timeelement_rolling_frequency;
    this.rolling_time_format = source.timeelementsettings[0].pagination_timeelement_rolling_time_format;
    this.today_format = source.timeelementsettings[0].pagination_timeelement_today_format;
    this.yesterday_format = source.timeelementsettings[0].pagination_timeelement_yesterday_format;

    // pipeline settings
    this.schedule = source.pipelinesettings[0].pipeline_frequency_schedule || null;
    this.interval = source.pipelinesettings[0].pipeline_frequencyinterval || null;


    // pagination settings
    this.pagination_type = source.paginationtype.id;
    this.cursor_key = source.paginationsettings[0].pagination_cursor_key || null;
    this.user_key = source.paginationsettings[0].pagination_user_key || null;
    this.user_key_url = source.paginationsettings[0].pagination_user_key_url || null;
    this.pagination_param_for_body_update = source.paginationsettings[0].pagination_param_for_body_update || null;
};

Source.create = async (source) => {
    let insert = await sql.query("INSERT INTO ic_source_adv_rest SET ?", source);
    if (insert.insertId) {
        return insert.insertId;
    }
    else {
        return;
    }
};

Source.update = async (source) => {
    let sqlQuery = `UPDATE ic_source_adv_rest
           SET source_name = ?,
           endpoint_url = ?,
           method = ?,
           body = ?,
           authentication_type = ?,
           refresh_token_endpoint_url = ?,
           refresh_token_endpoint_header = ?,
           refresh_token_endpoint_body = ?,
           refresh_token_endpoint_method = ?,
           username = ?,
           password = ?,
           customer_id = ?,
           pagination_type = ?,
           cursor_key = ?,
           user_key = ?,
           user_key_url = ?,
           pagination_param_for_body_update = ?
           WHERE id = ?`;

    let data = [
        source.source_name,
        source.endpoint_url,
        source.method,
        source.body,
        source.authentication_type,
        source.refresh_token_endpoint_url,
        source.refresh_token_endpoint_header,
        source.refresh_token_endpoint_body,
        source.refresh_token_endpoint_method,
        source.username,
        source.password,
        source.customer_id,
        source.pagination_type,
        source.cursor_key,
        source.user_key,
        source.user_key_url,
        source.pagination_param_for_body_update,
        source.id
    ];

    let row = await sql.query(sqlQuery, data);
    if (!row.affectedRows) {
        throw "Error while updating the source";
    }
    return row;
};

Source.getSources = async (value) => {
    let rows = await sql.query(`SELECT source_name, id FROM ic_source_adv_rest WHERE customer_id = ?`, [value]);
    if (rows.length) {
        return rows;
    } else {
        return [];
    }
};

Source.getSourcesAndSourcesRepeat = async (value) => {
    let rows = await sql.query(`SELECT t1.*, t2.Key, t2.Value FROM ic_source_adv_rest t1 INNER JOIN ic_source_adv_rest_452_repeat t2 ON t2.parent_id = t1.id WHERE t1.id = ?`, [value]);
    if (rows.length) {
        return rows;
    } else {
        return null;
    }
};
module.exports = Source;

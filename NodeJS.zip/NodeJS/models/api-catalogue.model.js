const sql = require("./db.js");
// const https    = require("https");

const Catalogue = {
    getCategory: async () => {
        let category = [];
        let rows = await sql.query(`SELECT * FROM yybiz_api_category WHERE status = 1`);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let bid = item.brand_ids
                let data = {
                    id: item.ID,
                    category: item.category_name,
                    brands: bid.split(",").map(Number)
                }
                category.push(data);
            });
            return category;
        } else {
            throw "Error while fetching category";
        }
    },

    getAllCategoryCount: async () => {
        let rows = await sql.query(`SELECT count(ID) as categoryCount FROM yybiz_api_category WHERE status = 1`);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            return arr[0].categoryCount;
        } else {
            throw "Error in getting count";
        }
    },

    getAllCategories: async (min, max, cnt, sort, order, q) => {
        let categoryList = [];
		var default_sort = 'updated_date';
		var default_order = 'DESC';
        var rows = '';
        let query = `SELECT c.* FROM yybiz_api_category as c where c.status = 1  `;
        
        if(q != "") {
            query += ' and (category_name like "%'+q+'%") ';
        }
        
        var parameters = (sort ? sort : default_sort)+' '+(order ? order : default_order);
        var sqlQ = query+' ORDER BY '+parameters;

		 if(min !== "" && max !== "") {
			let sqlquery = sqlQ+' LIMIT '+min+' , '+max;
			rows = await sql.query(sqlquery);
		} else {
			rows = await sql.query(sqlQ);
        }

        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    created_date: item.created_date,
                    updated_date: item.updated_date,
                    category: item.category_name
                }
                categoryList.push(data);
            });
            if(q != '') { cnt = rows.length;}
            let categoryData = {"total_count": cnt, "records": categoryList };
            return categoryData;
        } else {
            let categoryData = {"total_count": 0, "records": [] };
            return categoryData;
        }
    },

    createCategory: async (values) => {
        let sqlQuery = `INSERT INTO yybiz_api_category SET ?`;
        let data = {
            category_name: values.category
        };
        let row = await sql.query(sqlQuery, data);
        if (row.affectedRows) {
            return true;
        } else {
            throw "Error while Inserting the Record";
        }
    },

    editCategory: async (ID) => {
        let category = [];
        let rows = await sql.query(`SELECT c.* from yybiz_api_category as c where c.status=1 and c.ID = ?`, ID);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    created_date: item.created_date,
                    updated_date: item.updated_date,
                    category: item.category_name,
                    status: item.status
                }
                category.push(data);
            });
            return category;
        } else {
            throw "Error while fetching category";
        }
    },

    updateCategory: async (values) => {
        let sqlQuery = `UPDATE yybiz_api_category SET category_name = ? WHERE ID = ?`;
        let data = [
            values.category,
            values.ID
        ];
        let row = await sql.query(sqlQuery, data);
        if (row.affectedRows) {
            return true;
        }else{
            throw "Error while updating the Record";
        }
    },

    deleteCategory: async (ID) => {
        let row = await sql.query(`UPDATE yybiz_api_category SET status = ? WHERE ID = ?`, [0, ID]);
        if (row.affectedRows) {
            return true;
        }else {
          throw "Not existed";
        }
    },

    getBrand: async (brand_id_arr) => {
        let brand = [];
        let str = brand_id_arr.toString();
        let rows = await sql.query(`SELECT * FROM yybiz_api_brand WHERE FIND_IN_SET(ID, "${str}")`);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    brand: item.brand_name
                }
                brand.push(data);
            });
            return brand;
        } else {
            throw "Error while fetching brand";
        }
    },

    getPrice: async () => {
        let price = [];
        let rows = await sql.query(`SELECT * FROM yybiz_api_price_and_deal WHERE status = 1`);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    price: item.price_type,
                }
                price.push(data);
            });
            return price;
        } else {
            throw "Error while fetching price";
        }
    },

    getType: async () => {
        let type = [];
        let rows = await sql.query(`SELECT * FROM yybiz_api_type WHERE status = 1`);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    type: item.type,
                }
                type.push(data);
            });
            return type;
        } else {
            throw "Error while fetching type";
        }
    },

    getApiMethod: async () => {
        let method = [];
        let rows = await sql.query(`SELECT * FROM yybiz_api_method WHERE status = 1`);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    method: item.method,
                }
                method.push(data);
            });
            return method;
        } else {
            throw "Error while fetching method";
        }
    },

    getApiAuthType: async () => {
        let method = [];
        let rows = await sql.query(`SELECT * FROM yybiz_api_authentication_type WHERE status = 1`);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    type: item.type,
                }
                method.push(data);
            });
            return method;
        } else {
            throw "Error while fetching authorization type";
        }
    },

    insertApiCatalogue: async (object) => {
        let store_object = {
            api_category: object.api_category,
            api_brand: object.api_brand,
            api_price: object.api_price,
            api_type: object.api_type,
            api_commerce: object.api_commerce,
            api_version: object.api_version,
            api_product_name: object.api_product_name,
            //api_business_object: object.api_business_object,
            created_by: object.api_created_by,
            create_ip_address: object.create_ip_address,
            api_source_name: object.api_source_name,
            api_object_keyword: object.api_object_keyword,
            api_description: object.api_description,
            filter_type: object.filter_type,
            parameter1: object.parameter1,
            parameter2: object.parameter2,
            parameter3: object.parameter3,
            parameter4: object.parameter4,
            input_structure_json: object.input_structure_json,
            input_structure_hash: object.input_structure_hash
        }
        //console.log(store_object);
        let insert = await sql.query(`INSERT INTO yybiz_api_catalogue_source SET ?`, store_object);
		let business_obj_sql = `INSERT INTO yybiz_api_catalog_business_obj SET ?`;
		if (insert.insertId) {
			if(typeof object.api_business_object !== 'undefined' && object.api_business_object.length > 0)
			{
				const objArray = object.api_business_object;
				objArray.forEach(async element => { // Iterating business_obj_data param over the array and inserting into the table (by Mallikarjuna Nayak on 31-05-2022)
					var business_obj_data  = {
					  catalog_id : insert.insertId,
					  business_obj: element,
					};
					let business_obj_data_ins = await sql.query(business_obj_sql, business_obj_data);
				});
			}
			return true;
		} else {
            throw "Error while creating catalogue";
          }
    },

    getTotalCatalogCount: async () => {
        let query = `SELECT
        count(table1.id) as catalogCount
        FROM yybiz_api_catalogue_source as table1 JOIN yybiz_api_category as table2 ON table1.api_category=table2.ID
        JOIN yybiz_api_brand as table3 ON table1.api_brand=table3.ID
        JOIN yybiz_api_type as table4 ON table1.api_type=table4.ID
        JOIN yybiz_api_price_and_deal as table5 ON table1.api_price=table5.ID WHERE table1.is_deleted=0`

        let rows = await sql.query(query);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            return arr[0].catalogCount;
        } else {
            throw "Error in getting count";
        }
    },

    getApiCatalogue: async (min, max, cnt, sort, order, q) => {
        let catalogue = [];
		var default_sort = 'table1.updated_date';
		var default_order = 'DESC';
        var rows = '';
        let query = `SELECT table1.ID, table1.api_source_name, table1.api_commerce, table1.api_version, table1.api_product_name, table1.api_business_object, table2.ID as category_id, table2.category_name as category_name, table3.ID as brand_id, table3.brand_name as brand_name, table4.ID as type_id, table4.type as type, table5.ID as price_id, table5.price_type as price_type FROM yybiz_api_catalogue_source as table1 JOIN yybiz_api_category as table2 ON table1.api_category=table2.ID JOIN yybiz_api_brand as table3 ON table1.api_brand = table3.ID JOIN yybiz_api_type as table4 ON table1.api_type = table4.ID JOIN yybiz_api_price_and_deal as table5 ON table1.api_price = table5.ID WHERE is_deleted = 0 `;
        
        if(q != "") {
            query += ' and (table1.api_source_name like "%'+q+'%" or table1.api_product_name like "%'+q+'%" or table1.api_business_object like "%'+q+'%" or table4.type like "%'+q+'%") ';
        }

		var parameters = (sort ? sort : default_sort)+' '+(order ? order : default_order);
        var sqlQ = query+' ORDER BY '+parameters;

		 if(min !== "" && max !== "") {
			let sqlquery = sqlQ+' LIMIT '+min+' , '+max;
			rows = await sql.query(sqlquery);
		} else {
			rows = await sql.query(sqlQ);
        }

        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.ID,
                    api_source_name: item.api_source_name,
                    api_version: item.api_version,
                    api_product_name: item.api_product_name,
                    api_business_object: item.api_business_object,
                    category: {"id": item.category_id, "name": item.category_name},
                    brand: {"id": item.brand_id, "name": item.brand_name},
                    type: {"id": item.type_id, "name": item.type},
                    price: {"id": item.price_id, "name": item.price_type}
                }
                catalogue.push(data);
            });
            let catalogueData = {"total_count": cnt, "records": catalogue };
            return catalogueData;
        } else {
            let catalogueData = {"total_count": 0, "records": [] };
            return catalogueData;
        }
    },
	
	getApiCatalogueSource: async (id) => {
        let catalogue = [];
        let query = `SELECT 
        table1.ID,
        table1.api_source_name, 
        table1.api_commerce, 
        table1.api_version, 
        table1.api_product_name, 
        table1.api_business_object,
        table1.input_structure_json,
        table1.created_by,
        table2.ID as category_id, 
        table2.category_name as category_name, 
        table3.ID as brand_id, 
        table3.brand_name as brand_name, 
        table4.ID as type_id, 
        table4.type as type, 
        table5.ID as price_id, 
        table5.price_type as price_type,
        GROUP_CONCAT(table6.business_obj) as business_obj,
		u2.first_name as fname_updatedby, u2.last_name as lname_updatedby,
        u3.first_name as fname_createdby, u3.last_name as lname_createdby
        FROM yybiz_api_catalogue_source as table1
        LEFT JOIN yybiz_users as u2 on table1.updated_by = u2.ID
        LEFT JOIN yybiz_users as u3 on table1.created_by = u3.ID
        JOIN yybiz_api_category as table2 ON table1.api_category=table2.ID 
        JOIN yybiz_api_brand as table3 ON table1.api_brand=table3.ID 
        JOIN yybiz_api_type as table4 ON table1.api_type=table4.ID 
        JOIN yybiz_api_catalog_business_obj as table6 ON table6.catalog_id = table1.ID
        JOIN yybiz_api_price_and_deal as table5 ON table1.api_price=table5.ID WHERE table1.is_deleted=0 and table1.ID = ? `
        let rows = await sql.query(query, [id]);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
			arr.forEach(function (item) {
                let bObj = item.business_obj.split(",");
                let data = {
                    id: item.ID,
                    api_source_name: item.api_source_name,
                    api_version: item.api_version,
                    api_product_name: item.api_product_name,
                    api_business_object: bObj,
                    api_commerce: item.api_commerce,
                    category: {"id": item.category_id, "name": item.category_name},
                    brand: {"id": item.brand_id, "name": item.brand_name},
                    type: {"id": item.type_id, "name": item.type},
                    price: {"id": item.price_id, "name": item.price_type},
                    api_input_structure: JSON.parse(item.input_structure_json),
                    updated_by: item.fname_updatedby ? item.fname_updatedby+' '+item.lname_updatedby : '',
				    created_by: item.created_by ? item.fname_createdby+' '+item.lname_createdby : item.first_name+' '+item.last_name,
                }
                catalogue.push(data);
            });
            return catalogue;
        } else {
            throw "Error while fetching catalogue";
        }
    }
}
/**
 * Purpose: Update api_catalogue_source details with the specified id in the request
 * Author: Mallikarjuna Nayak
 * Date: 22-02-2022
 */
Catalogue.updateApiCatalogueSource = async (values) => {
	let sqlQuery = `UPDATE yybiz_api_catalogue_source SET updated_by = ?, update_ip_address = ?, api_category = ?, api_brand = ?, api_price = ?, api_type = ?, api_source_name = ?, api_commerce = ?, api_version = ?, api_product_name = ?, api_object_keyword = ?, api_description = ?,  input_structure_json = ?, input_structure_hash = ?, filter_type = ?, parameter1 = ?, parameter2 = ?, parameter3 = ?, parameter4 = ? WHERE ID = ?`;

    let data = [
		values.api_updated_by,
		values.update_ip_address,
		values.api_category,
		values.api_brand,
		values.api_price,
		values.api_type,
		values.api_source_name,
		values.api_commerce,
		values.api_version,
		values.api_product_name,
		//values.api_business_object,
		values.api_object_keyword,
		values.api_description,
		values.input_structure_json,
		values.input_structure_hash,
		values.filter_type,
		values.parameter1,
		values.parameter2,
		values.parameter3,
		values.parameter4,
		values.id
	];
	let row = await sql.query(sqlQuery, data);
	if (row.affectedRows) {
		/****** Logic for api_business_object starts here by Mallikarjuna Nayak on 31-05-2022******/
		let business_obj_sql = `INSERT INTO yybiz_api_catalog_business_obj SET ?`;
		if(typeof values.api_business_object !== 'undefined' && values.api_business_object.length > 0)
		{
			let has_business_obj = await sql.query(`SELECT id, catalog_id, business_obj FROM yybiz_api_catalog_business_obj WHERE catalog_id = ? `, [values.id]);
			if(has_business_obj.length)
			{
				let business_obj_del = await sql.query(`DELETE FROM yybiz_api_catalog_business_obj WHERE catalog_id = ?`, values.id);
				const grpArray = values.api_business_object;
				grpArray.forEach(async element => { // Iterating businessObject ids over the array and inserting into the table
					var post  = {
					  catalog_id: values.id,
					  business_obj: element,
					};
					let business_obj_ins = await sql.query(business_obj_sql, post);
				});
				
			}else{
				const grpArray = values.api_business_object;
				grpArray.forEach(async element => { // Iterating businessObject ids over the array and inserting into the table
					var post  = {
					  catalog_id: values.id,
					  business_obj: element,
					};
					let business_obj_ins = await sql.query(business_obj_sql, post);
				});
			}
		} else {
			let business_obj_del = await sql.query(`DELETE FROM yybiz_api_catalog_business_obj WHERE catalog_id = ?`, values.id);
		}
		/******* Logic for api_business_object ends here *******/
		return true;
	}else{
		throw "Error while updating the Record";
	}
};
/*  Purpose: Delete user_group data by id
*   Author: Mallikarjuna Nayak
*	Date: 22-02-2022
*/
Catalogue.deleteApiCatalogueSource = async (ID) => {
	let row = await sql.query(`UPDATE yybiz_api_catalogue_source SET is_deleted = ? WHERE ID = ?`, ['1', ID]);
  if (row.affectedRows) {
	  let cat_business_obj_del = await sql.query(`DELETE FROM yybiz_api_catalog_business_obj WHERE catalog_id = ?`, ID);
	  return true;
  }else {
	  throw "Not existed";
  }
};
/*  Purpose: Get all Brands data in the request
*   Author: Mallikarjuna Nayak
*	Date: 24-02-2022
*/
Catalogue.getAllBrands = async (min, max, cnt, sort, order, q) => {
	let allBrands = [];
	var default_sort = 'updated_date';
    var default_order = 'DESC';
    var rows = "";
    var query = `SELECT ID, created_date, updated_date, brand_name, status FROM yybiz_api_brand WHERE status = 1 `;

    if(q != "") {
        query += ' and (brand_name like "%'+q+'%") ';
    }

    var parameters = (sort ? sort : default_sort)+' '+(order ? order : default_order);
    var sqlQ = query+' ORDER BY '+parameters;

    if(min !== "" && max !== "") {
        let sqlquery = sqlQ+' LIMIT '+min+' , '+max;
        rows = await sql.query(sqlquery);
    } else {
        rows = await sql.query(sqlQ);
    }

    if (rows.length) {
        let arr = Object.values(JSON.parse(JSON.stringify(rows)));
        arr.forEach(function (item) {
            let data = {
                id: item.ID,
                created_date: item.created_date,
                updated_date: item.updated_date,
                brand_name: item.brand_name,
                status: (item.status == 1) ? true : false,
            }
            allBrands.push(data);
        });
        if(q != '') { cnt = rows.length;}
        allBrandsData = {"total_count": cnt, "records": allBrands };
        return allBrandsData;
    } else {
        let allBrandsData = {"total_count": 0, "records": [] };
        return allBrandsData;
    }	
};
Catalogue.getTotalBrands = async () => {
	let query = `SELECT count(ID) as brandsCount FROM yybiz_api_brand where status = 1`;
	let rows = await sql.query(query);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		return arr[0].brandsCount;
	} else {
		throw "Error in getting count";
	}
}
/*  Purpose: Add new Brand data
*   Author: Mallikarjuna Nayak
*	Date: 24-02-2022
*/
Catalogue.CreateNewBrand = async (values) => {
  /*
  CREATE TABLE `guidednav`.`yybiz_category_brand_map` ( `id` INT NOT NULL AUTO_INCREMENT , `brand_id` INT NOT NULL , `category_id` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB; 
  */
	let sqlQuery = `INSERT INTO yybiz_api_brand SET ?`;
	let brandCatSql = `INSERT INTO yybiz_category_brand_map SET ?`;
	let data = {
		brand_name: values.brand_name,
	};
	let row = await sql.query(sqlQuery, data);
	if (row.affectedRows) {
		if(typeof values.brandCategory !== 'undefined' && values.brandCategory.length > 0)
		{
			const grpArray = values.brandCategory;
			grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
				var post  = {
				  brand_id: row.insertId,
				  category_id: element,
				};
				let brand_cat_row = await sql.query(brandCatSql, post);
			});
		}
		return true;
	} else {
    throw "Error while Inserting the Record";
  }
};
/*  Purpose: Get brand_category_map data by id to edit
*   Author: Mallikarjuna Nayak
*	Date: 24-02-2022
*/
Catalogue.getbrandCatMap = async (ID) => {
	let brandCategory = [];
  let rows = await sql.query(`SELECT bcm.category_id AS brandCategory FROM yybiz_category_brand_map as bcm WHERE bcm.brand_id = ?`, [ID]);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			brandCategory.push(item.brandCategory);
		});
	}
  return brandCategory;
};
/*  Purpose: Get Brand data by id to edit
*   Author: Mallikarjuna Nayak
*	Date: 24-02-2022
*/
Catalogue.editBrand = async (ID, brandCategory) => {
	let brandCat = [];
	let rows = await sql.query(`SELECT ID, brand_name, created_date, updated_date, status FROM yybiz_api_brand WHERE ID = ?`, ID);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			let data = {
				id: item.ID,
				created_date: item.created_date,
				updated_date: item.updated_date,
				brand_name: item.brand_name,
				status: (item.status == 1) ? true : false,
				brandCategory: (brandCategory.length) ? brandCategory : ''
			}
			brandCat.push(data);
		});
		return brandCat;
	} else {
		throw "Error while fetching User_group data";
	}
};
/*  Purpose: Update user_group data by id to modify
*   Author: Mallikarjuna Nayak
*	Date: 14-02-2022
*/
Catalogue.updateBrand = async (values) => {
    let update_date_time = new Date();
	let sqlQuery = `UPDATE yybiz_api_brand SET brand_name = ?, status = ?, updated_date = ? WHERE ID = ?`;
	let data = [
		values.brand_name,
		values.status,
        update_date_time,
		values.ID
	];
	let row = await sql.query(sqlQuery, data);
	
	/****** Logic for brandCategory starts here ******/
	let category_brand_map = `INSERT INTO yybiz_category_brand_map SET ?`;
	if(typeof values.brandCategory !== 'undefined' && values.brandCategory.length > 0)
	{
		let brand_has_cat = await sql.query(`SELECT id, brand_id, category_id FROM yybiz_category_brand_map WHERE brand_id = ? `, [values.ID]);
		if(brand_has_cat.length)
		{
			let brand_cat_del = await sql.query(`DELETE FROM yybiz_category_brand_map WHERE brand_id = ?`, values.ID);
			const grpArray = values.brandCategory;
			grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
				var post  = {
				  brand_id: values.ID,
				  category_id: element,
				};
				let brand_cat_row = await sql.query(category_brand_map, post);
			});
			
		}else{
			const grpArray = values.brandCategory;
			grpArray.forEach(async element => { // Iterating userGroup ids over the array and inserting into the table
				var post  = {
				  brand_id: values.ID,
				  category_id: element,
				};
				let brand_cat_row = await sql.query(category_brand_map, post);
			});
		}
	} else {
    let brand_cat_del = await sql.query(`DELETE FROM yybiz_category_brand_map WHERE brand_id = ?`, values.ID);
  }
	/******* Logic for userGroup ends here *******/
	
	if (row.affectedRows) {
		return true;
	}else{
		throw "Error while updating the Record";
	}
};
/*  Purpose: Soft delete brand data by id
*   Author: Mallikarjuna Nayak
*	Date: 24-02-2022
*/
Catalogue.deleteBrand = async (ID) => {
	let row = await sql.query(`UPDATE yybiz_api_brand SET status = ? WHERE ID = ?`, [0, ID]);
  if (row.affectedRows) {
	  let brand_cat_del = await sql.query(`DELETE FROM yybiz_category_brand_map WHERE brand_id = ?`, ID);
    return true;
  }else {
	  throw "Not existed";
  }
};
/*  Purpose: Get brands data by specified category_id in the request
*   Author: Mallikarjuna Nayak
*	Date: 24-02-2022
*/
Catalogue.getBrandsByCatId = async (ID) => {
	let brandCat = [];
	let rows = await sql.query(`SELECT b.ID, b.brand_name FROM yybiz_api_brand as b LEFT JOIN yybiz_category_brand_map as cbm ON cbm.brand_id = b.ID WHERE b.status = 1 AND cbm.category_id = ?`, ID);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			let data = {
				id: item.ID,
				brand_name: item.brand_name,
			}
			brandCat.push(data);
		});
		return brandCat;
	} else {
		throw "Error while fetching User_group data";
	}
};
/*  Purpose: The following function is defined for to get Catalogue Source and Target
 * Author: Mallikarjuna Nayak
 * Date: 06-04-2022
*/
Catalogue.getCatalogueSourceTarget = async (searchkey, type) => {
	let brandCat = [];
	let rows = await sql.query(`SELECT ID, api_product_name FROM yybiz_api_catalogue_source WHERE is_deleted = 0 AND api_type=` + type +` AND api_product_name LIKE '%` + searchkey +`%'`);
		if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			let data = {
				id: item.ID,
				product_name: item.api_product_name,
			}
			brandCat.push(data);
		});
		return brandCat;
	}else {
		throw "Something went wrong while fetching the data";
	}
};

Catalogue.getBussinessObject = async (type) => {
    let businessObject = [];
    let rows = await sql.query(`SELECT id, catalog_id, business_obj FROM yybiz_api_catalog_business_obj WHERE catalog_id=` + type);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			let data = {
				id: item.id,
				business_obj: item.business_obj,
			}
			businessObject.push(data);
		});
		return businessObject;
	} else {
		throw "Error while fetching business objects";
	}
};

module.exports = Catalogue;
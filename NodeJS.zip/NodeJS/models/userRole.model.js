const sql = require("./db.js");
const config = require("../config/config.js");

const UserRole = function(UserRole){
	this.id = UserRole.id;
	this.role_name = UserRole.role_name;
	this.status = UserRole.status;
	this.created_date = UserRole.created_date;
};

/*  Purpose: Get all User_group data in the request
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.userRoles = async (min, max, cnt, sort, order) => {
	let userRole = [];
	var default_sort = 'created_date';
	var default_order = 'DESC';
	var rows = '';
	var query = `SELECT id, role_name, status, created_date FROM roles WHERE status = '1' `;
	var parameters = (sort ? sort : default_sort)+' '+(order ? order : default_order);
	var sqlQ = query+' ORDER BY '+parameters;

	if(min !== "" && max !== "") {
		let sqlquery = sqlQ+' LIMIT '+min+' , '+max;
		rows = await sql.query(sqlquery);
	} else {
		rows = await sql.query(sqlQ);
	}

        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.id,
                    role_name: item.role_name,
                    status: (item.status == 1) ? 'Active' : 'Inactive',
					created_date: item.created_date,
                }
                userRole.push(data);
            });
            userRoleData = {"total_count": cnt, "records": userRole };
            return userRoleData;
        } else {
            let userRoleData = {"total_count": cnt, "records": [] };
			return userRoleData;
        }	
};
UserRole.getTotaluserRoles = async () => {
	let query = `SELECT count(id) as userRoleCount FROM roles where status = '1'`;
	let rows = await sql.query(query);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		return arr[0].userRoleCount;
	} else {
		throw "Error in getting count";
	}
}
/*  Purpose: Add new user role data
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.createUserRole = async (values) => {
	let query1 = "INSERT INTO roles SET ?";
	let data = {
		role_name: values.role_name,
    };
	let row = await sql.query(query1, data);
	if (row.affectedRows) {
		return true;
	} else {
    throw "Record not inserted";
  }
};

/*  Purpose: Get user role data by id to edit
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.editUserRole = async (id) => {
	let UserRole = [];
	let rows = await sql.query(`SELECT id, role_name, status, created_date FROM roles WHERE id = ?`, id);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			let data = {
				id: item.id,
				role_name: item.role_name,
				status: (item.status == 1) ? 'Active' : 'Inactive',
				created_date: item.created_date,
			}
			UserRole.push(data);
		});
		return UserRole;
	} else {
		throw "Error while fetching User role data";
	}
};
/*  Purpose: Update user role data by id to modify
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.updateUserRole = async (values) => {
	let row = await sql.query(`UPDATE roles SET role_name = ?, status = ? WHERE id = ?`, [values.role_name, '' + values.status + '', values.id]);
	if (row.affectedRows) {
		return true;
	}else{
		throw "Record not found";
	}
};
/*  Purpose: Delete user role data by id
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.deleteUserRole = async (id) => {
	let row = await sql.query(`UPDATE roles SET status = ? WHERE id = ?`, ['0', id]);
  if (row.affectedRows) {
    return true;
  }else {
	  throw "Not existed";
  }
};

/*  Purpose: Get all permissions data in the request
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.allPermissions = async (min, max, cnt, sort, order) => {
	let userRole = [];
	var default_sort = 'created_date';
	var default_order = 'DESC';
	var rows = '';
	var query = `SELECT id, perm_mod, perm_desc, status, created_date FROM permissions WHERE status = '1' `;
	var parameters = (sort ? sort : default_sort)+' '+(order ? order : default_order);
	var sqlQ = query+' ORDER BY '+parameters;

	if(min !== "" && max !== "") {
		let sqlquery = sqlQ+' LIMIT '+min+' , '+max;
		rows = await sql.query(sqlquery);
	} else {
		rows = await sql.query(sqlQ);
	}

        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.id,
                    perm_mod: item.perm_mod,
                    perm_desc: item.perm_desc,
                    status: (item.status == 1) ? 'Active' : 'Inactive',
					created_date: item.created_date,
                }
                userRole.push(data);
            });
            AllPermData = {"total_count": cnt, "records": userRole };
            return AllPermData;
        } else {
            let AllPermData = {"total_count": cnt, "records": [] };
			return AllPermData;
        }	
};
UserRole.getTotalPermissions = async () => {
	let query = `SELECT count(id) as permissionCount FROM permissions where status = '1'`;
	let rows = await sql.query(query);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		return arr[0].permissionCount;
	} else {
		throw "Error in getting count";
	}
}
/*  Purpose: Add new permission data
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.createPermission = async (values) => {
	let query1 = "INSERT INTO permissions SET ?";
	let data = {
		perm_mod: values.perm_mod,
		perm_desc: values.perm_desc,
    };
	let row = await sql.query(query1, data);
	if (row.affectedRows) {
		return true;
	} else {
    throw "Record not inserted";
  }
};

/*  Purpose: Get permission data by id to edit
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.editPermission = async (id) => {
	let UserRole = [];
	let rows = await sql.query(`SELECT id, perm_mod, perm_desc, status, created_date FROM permissions WHERE id = ?`, id);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			let data = {
				id: item.id,
				perm_mod: item.perm_mod,
				perm_desc: item.perm_desc,
				status: (item.status == 1) ? 'Active' : 'Inactive',
				created_date: item.created_date,
			}
			UserRole.push(data);
		});
		return UserRole;
	} else {
		throw "Error while fetching User role data";
	}
};
/*  Purpose: Update permissions data by id to modify
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.updatePermission = async (values) => {
	let row = await sql.query(`UPDATE permissions SET perm_mod = ?, perm_desc = ?, status = ? WHERE id = ?`, [values.perm_mod, values.perm_desc, '' + values.status + '', values.id]);
	if (row.affectedRows) {
		return true;
	}else{
		throw "Record not found";
	}
};
/*  Purpose: Delete permissions data by id
*   Author: Mallikarjuna Nayak
*	Date: 04-03-2022
*/
UserRole.deletePermission = async (id) => {
	let row = await sql.query(`UPDATE permissions SET status = ? WHERE id = ?`, ['0', id]);
  if (row.affectedRows) {
    return true;
  }else {
	  throw "Not existed";
  }
};


module.exports = UserRole;

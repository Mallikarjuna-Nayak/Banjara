const sql = require("./db.js");
const config = require("../config/config.js");
const fs = require('fs');
const integrationService = require("../helpers/integration-services");
const { exec } = require("child_process");

const IntBridge = function(IntBridge){
	this.id = IntBridge.id;
	this.source_id = IntBridge.source_id;
	this.source_name = IntBridge.source_name;
	this.src_business_obj_id = IntBridge.src_business_obj_id;
	this.source_business_obj = IntBridge.source_business_obj;
	this.source_postman_params = IntBridge.source_postman_params;
	this.target_id = IntBridge.target_id;
	this.target_name = IntBridge.target_name;
	this.tgt_business_obj_id = IntBridge.tgt_business_obj_id;
	this.target_business_obj = IntBridge.target_business_obj;
	this.target_postman_params = IntBridge.target_postman_params;
	this.integration_bridge_name = IntBridge.integration_bridge_name;
	this.created_by = IntBridge.created_by;
	this.updated_by = IntBridge.updated_by;
	this.created_ip_address = IntBridge.created_ip_address;
	this.updated_ip_address = IntBridge.updated_ip_address;
	this.json_conf_filename = IntBridge.json_conf_filename;
	this.py_conf_filename = IntBridge.py_conf_filename;
	this.status = IntBridge.status;
	this.created_date = IntBridge.created_date;
	this.updated_date = IntBridge.updated_date;
};




/*  Purpose: To create a file like .json or .py for Integration Bridge data
*   Author: Mallikarjuna Nayak
*	Date: 07-04-2022
*/
function intBridgeFileCreate(inputData, path)
{
	let data = JSON.stringify(inputData, null, 2);
	fs.writeFile(path, data, (err) => {
		if (err) throw err;
		//console.log('Data written to file');
		return true;
	});
};

/*  Purpose: Get all Integration Bridge data in the request
*   Author: Mallikarjuna Nayak
*	Date: 07-04-2022
*/
IntBridge.getAllIntBridge = async (min, max, cnt, sort, order, q) => {
	let ibData = [];
	var default_sort = 'created_date';
	var default_order = 'DESC';
	var rows = '';
	var query = `SELECT ib.*, usr.first_name, usr.last_name FROM yybiz_integration_bridge AS ib, yybiz_users AS usr WHERE ib.status = '1' AND ib.created_by = usr.id`;

	if(q != "") {
		query += ` AND CONCAT_WS('', ib.source_name, ib.target_name, ib.integration_bridge_name) LIKE '%` + q + `%'`;
	}

	var parameters = (sort ? sort : default_sort)+' '+(order ? order : default_order);
	var sqlQ = query+' ORDER BY '+parameters;

	if(min !== "" && max !== "") {
		let sqlquery = sqlQ+' LIMIT '+min+' , '+max;
		rows = await sql.query(sqlquery);
	} else {
		rows = await sql.query(sqlQ);
	}
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
				let data = {
                    id: item.id,
					source_id: item.source_id,
					source_name: item.source_name,
					src_business_obj_id: item.src_business_obj_id,
					source_business_obj: item.source_business_obj,
					source_postman_params: (item.source_postman_params) ? Buffer.from(item.source_postman_params, 'base64').toString('ascii') : '',
					target_id: item.target_id,
					target_name: item.target_name,
					tgt_business_obj_id: item.tgt_business_obj_id,
					target_business_obj: item.target_business_obj,
					target_postman_params: (item.target_postman_params) ? Buffer.from(item.target_postman_params, 'base64').toString('ascii') : '',
					integration_bridge_name: item.integration_bridge_name,
					created_by: item.first_name+' '+item.last_name,
					updated_by: ((item.updated_by!=null) ? item.first_name+' '+item.last_name : "" ),
					created_ip_address: item.created_ip_address,
					updated_ip_address: item.updated_ip_address,
					json_conf_filename: item.json_conf_filename,
					py_conf_filename: item.py_conf_filename,
					status: (item.status == 1) ? 'Active' : 'Inactive',
					created_date: item.created_date,
					updated_date: item.updated_date,
					service_status: item.service_status,
					mapping: item.mapping
				}
                ibData.push(data);
			});
            resData = {"total_count": cnt, "records": ibData };
			return resData;
        } else {
            let resData = {"total_count": cnt, "records": [] };
			return resData;
        }
};
IntBridge.getTotalIntBridge = async () => {
	let query = `SELECT count(id) AS intBridgeCount FROM yybiz_integration_bridge WHERE status = '1'`;
	let rows = await sql.query(query);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		return arr[0].intBridgeCount;
	} else {
		throw "No records";
	}
}
/*  Purpose: Create or Add new Integration Bridge data
*   Author: Mallikarjuna Nayak
*	Date: 07-04-2022
*/
IntBridge.createIntBridge = async (values) => {
	let query1 = "INSERT INTO yybiz_integration_bridge SET ?";
	let data = {
		source_id: values.source_id,
		source_name: values.source_name,
		src_business_obj_id: values.src_business_obj_id,
		source_business_obj: values.source_business_obj,
		// source_postman_params: Buffer.from(values.source_postman_params).toString('base64'),
		source_postman_params: values.source_postman_params,
		target_id: values.target_id,
		target_name: values.target_name,
		tgt_business_obj_id: values.tgt_business_obj_id,
		target_business_obj: values.target_business_obj,
		// target_postman_params: Buffer.from(values.target_postman_params).toString('base64'),
		target_postman_params: values.target_postman_params,
		integration_bridge_name: values.integration_bridge_name,
		created_by: values.created_by,
		created_ip_address: values.created_ip_address,
		mapping: values.mapping,
	};
	// let jsonformat = JSON.stringify({ bizdata_ops_restapi_source: values.source_postman_params, bizdata_ops_restapi_target: values.target_postman_params });
	let row = await sql.query(query1, data);
	if (row.affectedRows) {
		// Get Instance Name
		let objInstance = await IntBridge.getInstance();
		let rows = await sql.query(`UPDATE yybiz_integration_bridge SET json_conf_filename = ?, py_conf_filename = ? WHERE id = ?`, [objInstance.instance + '_' + row.insertId + '_' +  values.integration_bridge_name, objInstance.instance + '_' + row.insertId + '_' +  values.integration_bridge_name, row.insertId]);
		// Json format file and name creation
		let jsonFileName = objInstance.instance + '_' + row.insertId + '_' +  values.integration_bridge_name + '.json';
		let jsonfile = './IntBridgeFiles/' + jsonFileName;
		let servicefile = './IntBridgeFiles/' + objInstance.instance + '_' + row.insertId + '_' +  values.integration_bridge_name + '.service';

		var objSourceParams = JSON.parse(Buffer.from(values.source_postman_params, 'base64').toString('utf8')); 
		var objTargetParams = JSON.parse(Buffer.from(values.target_postman_params, 'base64').toString('utf8')); 

		let response = await integrationService.prepareServiceFile(objSourceParams, objTargetParams, jsonFileName, jsonfile, servicefile);
		if(response) {
			//Upload file
			exec('sudo ansible bizdata-dev1 -m copy -a "src='+jsonfile+' mode="0777" dest=/opt/pipeline/eZintegrations/bin"', (error, stdout, stderr) => {
				if (error) {
					throw `error: ${error.message}`;
				}
				if (stderr) {
				throw `stderr: ${stderr}`;
				}
			});
			exec('sudo ansible bizdata-dev1 -m copy -a "src='+servicefile+' mode="0777" dest=/etc/systemd/system/"', (error, stdout, stderr) => {
				if (error) {
					throw `error: ${error.message}`;
				}
				if (stderr) {
				throw `stderr: ${stderr}`;
				}
			});
			return true;
		} else {
			return false;
		}
	} else {
    throw "Record not inserted";
  }
};

/*  Purpose: Get Integration Bridge data by id to edit
*   Author: Mallikarjuna Nayak
*	Date: 07-04-2022
*/
IntBridge.editIntBridge = async (id) => {
	let intBridgeData;
	let rows = await sql.query(`SELECT ib.*, usr.first_name, usr.last_name FROM yybiz_integration_bridge AS ib, yybiz_users AS usr WHERE ib.created_by = usr.id AND ib.id = ?`, id);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			intBridgeData = {
				id: item.id,
				source_id: item.source_id,
				source_name: item.source_name,
				src_business_obj_id: item.src_business_obj_id,
				source_business_obj: item.source_business_obj,
				source_postman_params: (item.source_postman_params) ? Buffer.from(item.source_postman_params, 'base64').toString('ascii') : '',
				target_id: item.target_id,
				target_name: item.target_name,
				tgt_business_obj_id: item.tgt_business_obj_id,
				target_business_obj: item.target_business_obj,
				target_postman_params: (item.target_postman_params) ? Buffer.from(item.target_postman_params, 'base64').toString('ascii') : '',
				integration_bridge_name: item.integration_bridge_name,
				created_by: item.first_name+' '+item.last_name,
				updated_by: ((item.updated_by!=null)? item.first_name+' '+item.last_name : "" ),
				created_ip_address: item.created_ip_address,
				updated_ip_address: item.updated_ip_address,
				json_conf_filename: item.json_conf_filename,
				py_conf_filename: item.py_conf_filename,
				status: (item.status == 1) ? 'Active' : 'Inactive',
				created_date: item.created_date,
				updated_date: item.updated_date,
				service_status: item.service_status,
				mapping: item.mapping
			}
		});
		return intBridgeData;
	} else {
		throw "Record not found";
	}
};
/*  Purpose: Update Integration Bridge data by id to modify
*   Author: Mallikarjuna Nayak
*	Date: 07-04-2022
*/
IntBridge.updateIntBridge = async (values) => {
	let objInstance = await IntBridge.getInstance();
	let sqlQuery = `UPDATE yybiz_integration_bridge SET source_id = ?, source_name = ?, src_business_obj_id = ?, source_business_obj = ?, source_postman_params = ?, target_id = ?, target_name = ?, tgt_business_obj_id = ?, target_business_obj = ?, target_postman_params = ?, integration_bridge_name = ?, updated_by = ?, updated_ip_address = ?, json_conf_filename = ?, mapping = ? WHERE id = ?`;
	let data = [
		values.source_id,
		values.source_name,
		values.src_business_obj_id,
		values.source_business_obj,
		values.source_postman_params,
		values.target_id,
		values.target_name,
		values.tgt_business_obj_id,
		values.target_business_obj,
		values.target_postman_params,
		values.integration_bridge_name,
		values.updated_by,
		values.updated_ip_address,
		objInstance.instance + '_' + values.id + '_' +  values.integration_bridge_name,
		values.mapping,
		values.id
	];
	let row = await sql.query(sqlQuery, data);
	if (row.affectedRows) {
		let jsonFileName = objInstance.instance + '_' + values.id + '_' +  values.integration_bridge_name + '.json';
		let jsonfile = './IntBridgeFiles/' + jsonFileName;
		let servicefile = './IntBridgeFiles/' + objInstance.instance + '_' + values.id + '_' +  values.integration_bridge_name + '.service';

		var objSourceParams = JSON.parse(Buffer.from(values.source_postman_params, 'base64').toString('utf8')); 
		var objTargetParams = JSON.parse(Buffer.from(values.target_postman_params, 'base64').toString('utf8')); 

		let response = await integrationService.prepareServiceFile(objSourceParams, objTargetParams, jsonFileName, jsonfile, servicefile);
		if(response) {
			//Upload file
			exec('sudo ansible bizdata-dev1 -m copy -a "src='+jsonfile+' dest=/opt/pipeline/eZintegrations/bin"', (error, stdout, stderr) => {
				if (error) {
					throw `error: ${error.message}`;
				}
				if (stderr) {
				throw `stderr: ${stderr}`;
				}
			});
			exec('sudo ansible bizdata-dev1 -m copy -a "src='+servicefile+' dest=/etc/systemd/system/"', (error, stdout, stderr) => {
				if (error) {
					throw `error: ${error.message}`;
				}
				if (stderr) {
				throw `stderr: ${stderr}`;
				}
			});
			return true;
		} else {
			return false;
		}
	} else {
		throw "Record not inserted";
	  }
};
/*  Purpose: Delete Integration Bridge data by specified id
*   Author: Mallikarjuna Nayak
*	Date: 07-04-2022
*/
IntBridge.deleteIntBridge = async (id) => {
	let get_rec = await sql.query(`SELECT id, json_conf_filename, py_conf_filename FROM yybiz_integration_bridge WHERE status = ? AND id = ?`, [1, id]);
	let arr = Object.values(JSON.parse(JSON.stringify(get_rec)));
	var json_filePath = 'IntBridgeFiles/' + arr[0].json_conf_filename + '.json';
	var py_filePath = 'IntBridgeFiles/' + arr[0].py_conf_filename + '.service';
	fs.unlinkSync(json_filePath);
	fs.unlinkSync(py_filePath);
	let row = await sql.query(`UPDATE yybiz_integration_bridge SET status = ? WHERE id = ?`, [0, id]);
  if (row.affectedRows) {
    return true;
  }else {
	  throw "Record not found";
  }
};
/*  Purpose: Refresh Integration Bridge service
*   Author: Mallikarjuna Nayak
*	Date: 10-05-2022
*/
IntBridge.refreshService = async (id) => {
	let get_rec = await sql.query(`SELECT id, integration_bridge_name, source_postman_params, target_postman_params FROM yybiz_integration_bridge WHERE status = ? AND id = ?`, [1, id]);
	if(get_rec.length)
	{
		let objInstance = await IntBridge.getInstance();
		let IntBridgeName = Object.values(JSON.parse(JSON.stringify(get_rec)));
		let jsonFileName = objInstance.instance + '_' + id + '_' + IntBridgeName[0].integration_bridge_name + '.json';
		let jsonfile = './IntBridgeFiles/' + jsonFileName;
		let servicefile = './IntBridgeFiles/' + objInstance.instance + '_' + id + '_' + IntBridgeName[0].integration_bridge_name + '.service';
		var objSourceParams = JSON.parse(Buffer.from(IntBridgeName[0].source_postman_params, 'base64').toString('utf8')); 
		var objTargetParams = JSON.parse(Buffer.from(IntBridgeName[0].target_postman_params, 'base64').toString('utf8')); 
		
		let response = await integrationService.prepareServiceFile(objSourceParams, objTargetParams, jsonFileName, jsonfile, servicefile);
		if(response) {
			//Upload file
			exec('sudo ansible bizdata-dev1 -m copy -a "src='+jsonfile+' dest=/opt/pipeline/eZintegrations/bin"', (error, stdout, stderr) => {
				if (error) {
					throw `error: ${error.message}`;
				}
				if (stderr) {
					throw `stderr: ${stderr}`;
				}
			});
			exec('sudo ansible bizdata-dev1 -m copy -a "src='+servicefile+' dest=/etc/systemd/system/"', (error, stdout, stderr) => {
				if (error) {
					throw `error: ${error.message}`;
				}
				if (stderr) {
					throw `stderr: ${stderr}`;
				}
			});
			return true;
			} else {
				return false;
			}
	}else{
		throw "No Record found";
	}
};

IntBridge.getInstance = async () => {
	let data;
	let rows = await sql.query(`SELECT * FROM yybiz_instances`);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			data = {
				id: item.id,
				instance: item.instance
			}
		});
		return data;
	} else {
		throw "Error while fetching instance";
	}
};

IntBridge.editInstance = async (id) => {
	let data;
	let rows = await sql.query(`SELECT * FROM yybiz_instances WHERE id = ?`, id);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			data = {
				id: item.id,
				instance: item.instance
			}
		});
		return data;
	} else {
		throw "Record not found";
	}
};

IntBridge.updateInstance = async (values) => {
	let row = await sql.query(`UPDATE yybiz_instances SET instance = ? WHERE id = ?`, [values.instance, values.id]);
	if (row.affectedRows) {
		return true;
	}else{
		throw "Record not found";
	}
};

IntBridge.getPostmanData = async (id) => {
	let data;
	let rows = await sql.query(`SELECT input_structure_json FROM yybiz_api_catalogue_source WHERE id = ?`, id);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			data = {
				input_structure_json: JSON.parse(item.input_structure_json)
			}
		});
		return data;
	} else {
		throw "Record not found";
	}
};

IntBridge.getServiceStatus = async (id) => {
	let data;
	let rows = await sql.query(`SELECT service_status FROM yybiz_integration_bridge WHERE id = ?`, id);
	if (rows.length) {
		let arr = Object.values(JSON.parse(JSON.stringify(rows)));
		arr.forEach(function (item) {
			data = {
				service_status: JSON.parse(item.service_status)
			}
		});
		return data;
	} else {
		throw "Record not found";
	}
};

IntBridge.setServiceStatus = async (service_status, id) => {
	let row = await sql.query(`UPDATE yybiz_integration_bridge SET service_status = ? WHERE id = ?`, [service_status, id]);
	if (row.affectedRows) {
		return true;
	} else {
		throw "Record not found";
	}
};

module.exports = IntBridge;

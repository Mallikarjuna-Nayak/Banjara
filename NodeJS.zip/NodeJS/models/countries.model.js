const sql = require("./db.js");

const Countries = {
    getAllCountries: async ( ) => {
        let countries = [];
        let rows = await sql.query(`SELECT * FROM yybiz_countries`);
        if (rows.length) {
            let arr = Object.values(JSON.parse(JSON.stringify(rows)));
            arr.forEach(function (item) {
                let data = {
                    id: item.id,
                    country_name: item.country_name,
                    dial_code: item.dial_code,
                    code: item.code
                }
                countries.push(data);
            });
            return countries;
        } else {
            throw "Error while fetching countries data";
        }
    }
}

module.exports = Countries;
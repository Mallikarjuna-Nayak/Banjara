const sql = require("./db.js");
const config = require("../config/config.js");

// constructor
const Target = function (target, userId) {
    if (typeof target.targetId != 'undefined') {
        this.id = target.targetId;
    }

    // target info
    this.target_name = target.dataTarget.name ? target.dataTarget.name : target.dataTarget

    // http properties
    this.rest_url = target.dataUrl;
    this.method = target.dataMethod.id;
    //this.body = target.body;

    // authentication
    this.authorization_type = target.authenticationtype.id;
    // this.refresh_token_endpoint_url = target.authenticationsettings[0]?.oauth_refresh_token_endpoint_url || null;
    // this.refresh_token_endpoint_header = target.authenticationsettings[0]?.oauth_refresh_token_endpoint_header || null;
    // this.refresh_token_endpoint_body = target.authenticationsettings[0]?.oauth_refresh_token_endpoint_body || null;
    // this.refresh_token_endpoint_method = target.authenticationsettings[0]?.oauth_refresh_token_endpoint_method || null;
    this.user_name = target.authenticationsettings[0].auth_Username || null;
    this.password = target.authenticationsettings[0].auth_password || null;

    // user details
    this.customer_id = userId;

    this.object_name = target.connectionsettings[0].ObjectName.id || null;
    this.max_connection = target.connectionsettings[0].maxConnection || null;

    this.content_type = target.contentsettings[0].contentType || null;
    this.message_format = target.contentsettings[0].messageFormat || null;


    // pagination settings
    //this.pagination_type = target.paginationtype.id;
    //this.cursor_key = target.paginationsettings[0]?.pagination_cursor_key || null;
    //this.user_key = target.paginationsettings[0]?.pagination_user_key || null;
    //this.user_key_url = target.paginationsettings[0]?.pagination_user_key_url || null;
    //this.pagination_param_for_body_update = target.paginationsettings[0]?.pagination_param_for_body_update || null;
};

Target.create = async (target) => {
    let insert = await sql.query("INSERT INTO ic_tgt_restful_api SET ?", target);
    if (insert.insertId) {
        return insert.insertId;
    }
    else {
        return;
    }
};

Target.update = async (target) => {
    let sql = `UPDATE ic_tgt_restful_api
           SET target_name = ?
           endpoint_url = ?
           method = ?
           body = ?
           authentication_type = ?
           refresh_token_endpoint_url = ?
           refresh_token_endpoint_header = ?
           refresh_token_endpoint_body = ?
           refresh_token_endpoint_method = ?
           username = ?
           password = ?
           customer_id = ?
           pagination_type = ?
           cursor_key = ?
           user_key = ?
           user_key_url = ?
           pagination_param_for_body_update = ?
           WHERE id = ?`;

    let data = [
        target.target_name,
        target.endpoint_url,
        target.method,
        target.body,
        target.authentication_type,
        target.refresh_token_endpoint_url,
        target.refresh_token_endpoint_header,
        target.refresh_token_endpoint_body,
        target.refresh_token_endpoint_method,
        target.username,
        target.password,
        target.customer_id,
        target.pagination_type,
        target.cursor_key,
        target.user_key,
        target.user_key_url,
        target.pagination_param_for_body_update,
        target.id
    ];

    let row = await sql.query(sql, data);
    if (!row.affectedRows) {
        throw "Error while updating the target";
    }
    return row;
};

Target.getTargets = async (value) => {
    let rows = await sql.query(`SELECT target_name, id FROM ic_tgt_restful_api WHERE customer_id = ?`, [value]);
    if (rows.length) {
        return rows;
    } else {
        return [];
    }
};

Target.getTargetsAndTargetsRepeat = async (value) => {
    let rows = await sql.query(`SELECT t1.*, t2.key1, t2.value1 FROM ic_tgt_restful_api t1 INNER JOIN ic_tgt_restful_api_285_repeat t2 ON t2.parent_id = t1.id WHERE t1.id = ?`, [value]);
    if (rows.length) {
        return rows;
    } else {
        return null;
    }
};
module.exports = Target;
